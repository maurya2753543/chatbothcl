import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material';

@Component({
  selector: 'app-notdialog',
  templateUrl: './notdialog.component.html',
  styleUrls: ['./notdialog.component.scss']
})
export class NotdialogComponent implements OnInit {
  username:any;
  constructor( public dialog: MatDialog) {
    this.username = JSON.parse(localStorage.getItem('AuthInfo')).userName
   }

  ngOnInit() {
  }

}
