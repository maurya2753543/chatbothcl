import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NotdialogComponent } from './notdialog.component';

describe('NotdialogComponent', () => {
  let component: NotdialogComponent;
  let fixture: ComponentFixture<NotdialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NotdialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NotdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
