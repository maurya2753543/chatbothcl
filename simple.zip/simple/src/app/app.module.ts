import { BrowserModule } from '@angular/platform-browser';
import { NgModule} from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { SharedModule } from '../app/shared/shared.module';
import { AppLoaderComponent } from '../app/shared/services/app-loader/app-loader.component';
import { ChatbotdialogComponent } from './chatbotdialog/chatbotdialog.component';
import { ChatService } from './services/chat/chat.service';
import {MatButtonModule} from '@angular/material/button';
import {MatDialogModule} from '@angular/material/dialog';
import {MatInputModule} from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';

import { HttpClientModule, /* other http imports */ } from "@angular/common/http";
import { Http, HttpModule } from '@angular/http';
import {MatRadioModule} from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import {MatGridListModule} from '@angular/material/grid-list';
import {MatCardModule} from '@angular/material/card';
import {MatTableModule} from '@angular/material/table';
import { ExcelService } from './services/ExcelService';
import { FlexLayoutModule } from '@angular/flex-layout';
import { NotdialogComponent } from './notdialog/notdialog.component';

@NgModule({
  declarations: [
    AppComponent,
    ChatbotdialogComponent,
    NotdialogComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    HttpModule,
    MatButtonModule,
    MatRadioModule,
    MatInputModule,
    HttpClientModule,
    MatDialogModule,
    FormsModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatSelectModule,
    MatGridListModule,
    MatCardModule,
    MatTableModule,
    FlexLayoutModule
    
  ],
  entryComponents:[
    ChatbotdialogComponent,
    NotdialogComponent
  ],

  providers: [AppLoaderComponent, ChatService,ExcelService],
  bootstrap: [AppComponent,]
})
export class AppModule {
 }
