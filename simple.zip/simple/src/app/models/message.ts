export class Message {
  text: any;
  description: any;
  content: string;
  show:Boolean;
  correctAnswer:any;
  
  
  
  constructor(content: string){
    this.content = content;
  
 
  }
   
}