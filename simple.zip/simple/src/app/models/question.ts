export class Question{
    questionText: any;
    optionList: any;
    optionName:any;
    optionId: any;

}