import { Component, OnInit, ViewChild } from '@angular/core';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { ReportService } from '../report.service';
import { MatSnackBar, MatTabGroup } from '@angular/material';
import { Router } from '@angular/router';
import { Chart } from 'chart.js';
import { appSessionErr, resetLocalStorage, appVariables, appGenericErr, snackBarDuration } from 'src/app/app.constants';

@Component({
  selector: 'app-bot-report',
  templateUrl: './bot-report.component.html',
  styleUrls: ['./bot-report.component.scss']
})
export class BotReportComponent implements OnInit {
  BarChart: any;
  pieChart: any;
  lineChart: any;
  dashboardData = [];
  p: Number = 1;
  public startDate;
  public endDate;
  selectedDay: string = '';

  constructor(
    private loader: AppLoaderService,
    private reportService: ReportService,
    private snackBar: MatSnackBar,
    private router: Router,
  ) { }

  ngOnInit() {
    this.selectedDay = "past30Days";
    this.getBotReport();

  }

  clear() {
    this.startDate = null;
    this.endDate = null;
    this.selectedDay = "";
    this.getBotReport();
  }
  selectChangeHandler(event: any) {
    //update the ui
    this.selectedDay = event.target.value;
    this.startDate = null;
    this.endDate = null;
    console.log('this selected day', this.selectedDay)
    this.getBotReport();

  }
  getBotReport() {
    this.loader.open();
    let reqObj = {
      startDate: this.startDate,
      endDate: this.endDate,
      selectedDay: this.selectedDay,
    }
    this.reportService.getBotReport(reqObj).subscribe(async res => {
      if (res.code == 200) {
        this.dashboardData = await res.data
        this.showBarChart(this.dashboardData);
        this.showPieChart(this.dashboardData);
        this.showLineChart(this.dashboardData);

      }
      this.loader.close();
    }, err => {
      this.loader.close();
    })
  }
  filterByDate() {

    if (this.startDate == undefined || this.endDate == undefined) {
      this.snackBar.open('Please select both dates', 'OK', { duration: snackBarDuration });
      return;
    }
    this.selectedDay = "";
    this.getBotReport();
  }
  showBarChart(dashboardData) {

    if (this.BarChart) {
      this.BarChart.destroy()
    }
    this.BarChart = new Chart('barChart', {
      type: 'bar',
      data: {
        labels: dashboardData.barchartData.intentArray,
        datasets: [{
          label: 'Intents',
          data: dashboardData.barchartData.intentOccuranceArray,
          backgroundColor: '#536a1b',

          borderColor: '#536a1b',
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "Intent occurance rate",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }
  showPieChart(dashboardData) {
    
    if (this.pieChart) {
      this.pieChart.destroy()
    }
    this.pieChart = new Chart('pieChart', {
      type: 'pie',
      data: {
        labels: dashboardData.pieChartData.intentCapturedArray,
        datasets: [{
          label: 'Intents',
          data: dashboardData.pieChartData.intentCapturedCountArray,
          backgroundColor: [
            '#536a1b','#dff0d8'
          ],
          borderColor: [
            '#536a1b','#dff0d8'
          ],
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "Intent identifaction rate",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: true
            }
          }]
        }
      }
    });
  }
  showLineChart(dashboardData) {
    console.log('show line chart,')
    if (this.lineChart) {
      this.lineChart.destroy()
    }
    this.lineChart = new Chart('lineChart', {
      type: 'line',
      data: {
        labels: dashboardData.lineChartData.dateArray,
        datasets: [{
          label: 'Input message',
          data: dashboardData.lineChartData.inputMessageCountArray,
          // backgroundColor: [
          //   '#536a1b'
          // ],
          borderColor: [
            '#536a1b'
          ],
          borderWidth: 1
        }]
      },
      options: {
        title: {
          text: "Input message (last 30 occurances)",
          display: true
        },
        scales: {
          yAxes: [{
            ticks: {
              beginAtZero: false
            }
          }]
        }
      }
    });
  }
}
