import { Component, OnInit } from '@angular/core';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { ReportService } from '../report.service';
import {ActivatedRoute} from '@angular/router'
@Component({
  selector: 'app-bot-report-detail',
  templateUrl: './bot-report-detail.component.html',
  styleUrls: ['./bot-report-detail.component.scss']
})
export class BotReportDetailComponent implements OnInit {
   p: Number = 1;
  paramRole: any;
  constructor( private loader: AppLoaderService,
    private reportService: ReportService,
    private activatedRoute: ActivatedRoute) { }
 public params: any = {
   'page': 1,
   'limit': 10
 }
 weakUnderstandingList: [];
 intentList: [];
 public totalItems: any =0;
 isWeakUnderstandingExists: boolean =false;
 isIntentListExists: boolean = false;
  ngOnInit() {
    this.activatedRoute.params.subscribe((param: any)=>{
      console.log('param<<<<<<<', param)
        this.paramRole = param.role;
      if(param.role == 'weakUnderstanding'){
        this.getWeakUnderstanding();
       }
       if(param.role == 'allIntents'){
        this.getAllIntents();

       }
    })
  }
  
pageChange(event: any): void{
  this.params.page = event;
  this.p = event;
  if(this.paramRole == 'weakUnderstanding'){
    this.getWeakUnderstanding();
  }
  if(this.paramRole == 'allIntents'){
    this.getAllIntents();
  }
}
getWeakUnderstanding(){
  this.loader.open();
  const obj = {
    'page': this.params.page,
    'limit': this.params.limit
  }
  this.reportService.getBotWeakUnderstanding(obj).subscribe(res => {
    if(res.code == 200){
       this.weakUnderstandingList = res.data;
       this.totalItems = res.data.count;
       if(this.weakUnderstandingList.length > 0){
         this.isWeakUnderstandingExists = true;
       }
       else{
        this.isWeakUnderstandingExists = false;
        }
    }
    this.loader.close();
  }, err => {
    this.loader.close();
  })
}
getAllIntents(){
  this.loader.open();
  const obj = {
    'page': this.params.page,
    'limit': this.params.limit
  }
  this.reportService.getAllIntents(obj).subscribe(res => {
    if(res.code == 200){
       this.intentList = res.data;
       this.totalItems = res.data.count;
       if(this.intentList.length > 0){
         this.isIntentListExists = true;
       }
       else{
        this.isIntentListExists = false;
        }
    }
    this.loader.close();
  }, err => {
    this.loader.close();
  })
}
}
