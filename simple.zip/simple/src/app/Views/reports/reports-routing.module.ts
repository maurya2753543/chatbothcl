import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ReportsComponent } from './reports.component';
import { AdminReportComponent } from './admin-report/admin-report.component';
import { AiReportComponent } from './ai-report/ai-report.component';
import { BotReportComponent } from './bot-report/bot-report.component';
import { BotReportDetailComponent } from './bot-report-detail/bot-report-detail.component';

const routes: Routes = [
  {path: '', component: ReportsComponent },
  {path: 'admin', component: AdminReportComponent },
  {path: 'ai', component: AiReportComponent },
  {path: 'bot-report', component: BotReportComponent},
  {path: 'bot-report/:role', component: BotReportDetailComponent},
  {path: 'bot-report/:role', component: BotReportDetailComponent}


];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ReportsRoutingModule { }
