import { Component, OnInit } from '@angular/core';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { DatePipe } from '@angular/common';
import { ReportService } from '../report.service';
import { MatSnackBar } from "@angular/material";
import { appSessionErr, resetLocalStorage, appVariables, appGenericErr, snackBarDuration } from 'src/app/app.constants';
import { Router } from '@angular/router';

import * as XLSX from 'xlsx';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  selector: 'app-admin-report',
  templateUrl: './admin-report.component.html',
  styleUrls: ['./admin-report.component.scss']
})
export class AdminReportComponent implements OnInit {

  public reportTypeList = ['Raw Data Report','User Assessment Report', 'Question Report', 'User Report','Summary Report'];
  public reportForm: FormGroup;
  public minDate: Date;
  public maxDate: Date;
  public rawDataReport: any[] = [];
  public summaryReport = null;
  public userAssessmentReport: any[] = [];
  public questionReport: any[] = [];
  public showReport = false;
  public currentPage: any;
  public questionBankList = [];
  public userAssessmentList = [];
  public userList = [];
  public rescheduledUserAssessmentList = [];
  public nonRescheduledUserAssessmentList = [];
  public assessmentConfig;
  public lobList = [];
  public lobConfig;
  public subLobList = [];
  public subLobConfig;
  public questionBankConfig;
  public userReport = [];

  constructor(
    private loader: AppLoaderService,
    private reportService: ReportService,
    private snackBar: MatSnackBar,
    private router: Router,
    private fb: FormBuilder
  ) { 
    // Set the minimum to January 1st 20 years in the past and December 31st a year in the future.
    const currentYear = new Date().getFullYear();
    this.minDate = new Date(currentYear - 20, 0, 1);
    //this.maxDate = new Date(currentYear + 1, 11, 31);
    this.maxDate = new Date();
    this.assessmentConfig = {
      displayKey:"assessmentName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.userAssessmentList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'assessmentName'
      }
      this.lobConfig = {
        displayKey:"lobName",
        search:true,
        height: '200px',
        placeholder:'Select',
        customComparator: ()=>{},
        limitTo: this.lobList.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder:'Search',
        searchOnKey: 'lobName'
      }
      this.subLobConfig = {
        displayKey:"subLobName",
        search:true,
        height: '200px',
        placeholder:'Select',
        customComparator: ()=>{},
        limitTo: this.subLobList.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder:'Search',
        searchOnKey: 'subLobName'
      }
      this.questionBankConfig = {
        displayKey:"questionBankName",
        search:true,
        height: '200px',
        placeholder:'Select',
        customComparator: ()=>{},
        limitTo: this.questionBankList.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder:'Search',
        searchOnKey: 'questionBankName'
      }
  }

  ngOnInit() {
    this.loader.close();
    //this.getQuestionBank();
    this.getAllLob();
    this.reportForm = this.fb.group({
      reportType: ['', Validators.required],
      fromDate: [''],
      toDate: [''],
      questionBankName: [''],
      selectedQB: [null],
      assessmentId: [''],
      selectedAssessment: [null],
      lob: [null],
      subLob : [null]
    })
  }

  getAllLob(){
    this.loader.open();
    this.reportService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.lobList = res;
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLob(){
    this.reportForm.get('subLob').setValue([]);
    this.reportForm.get('selectedQB').setValue([]);
    this.loader.open();
    this.reportService.getSubLob(this.reportForm.get('lob').value.lobName)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.subLobList = res;
        this.subLobConfig.limitTo = this.subLobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }


  validateDate(){
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'yyyy-MM-dd');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'yyyy-MM-dd');
    if(fromDate > toDate){
      this.snackBar.open('Start date cannot be greater then end date.', 'OK', {duration: snackBarDuration});
      return false;
    }else{
      return true;
    }
  }

  resetData(){
    this.currentPage = null;
    this.rawDataReport = [];
    this.userAssessmentReport = [];
    this.userReport = [];
    this.userList = [];
    this.userAssessmentList = [];
    this.questionReport = [];
    this.summaryReport = null;
    this.reportForm.get('fromDate').setValue('');
    this.reportForm.get('toDate').setValue('');
    this.reportForm.get('questionBankName').setValue('');
    this.reportForm.get('assessmentId').setValue('');
    this.reportForm.get('selectedAssessment').setValue([]);
    this.reportForm.get('lob').setValue([]);
    this.reportForm.get('subLob').setValue([]);
    this.reportForm.get('selectedQB').setValue([]);
    this.showReport = false;
    if(this.reportForm.get('reportType').value == 'Question Report'){
     this.toggleValidation(); 
    } else if(this.reportForm.get('reportType').value == 'User Report'){
      this.toggleValidationForUser();
    } else if(this.reportForm.get('reportType').value == 'User Assessment Report'){
      this.toggleValidationForUserAssessment();
    }else if(this.reportForm.get('reportType').value == 'Raw Data Report') {
      this.toggleValidationForRawData();
    } else if(this.reportForm.get('reportType').value == 'Summary Report'){
      this.toggleValidationForRawData();
    }
  }

  clearReports(){
    this.rawDataReport = [];
    this.userAssessmentReport = [];
    this.userReport = [];
    this.userList = [];
    this.userAssessmentList = [];
    this.questionReport = [];
    this.summaryReport = null;
    this.showReport = false;
  }

  clearUserAssessmentReport(){
    this.reportForm.get('assessmentId').setValue(this.reportForm.get('selectedAssessment').value.assessmentName);
    this.rawDataReport = [];
    this.userAssessmentReport = [];
    this.userList = [];
    this.questionReport = [];
    this.summaryReport = null;
    this.showReport = false;
  }

  toggleValidationForRawData(){
    this.reportForm.get('fromDate').setValidators(Validators.required);
    this.reportForm.get('toDate').setValidators(Validators.required);
    this.reportForm.get('questionBankName').clearValidators();
    this.reportForm.get('selectedQB').clearValidators();
    this.reportForm.get('selectedAssessment').clearValidators();
    this.reportForm.get('assessmentId').clearValidators();
    this.reportForm.get('lob').clearValidators();
    this.reportForm.get('subLob').clearValidators();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('questionBankName').updateValueAndValidity();
    this.reportForm.get('assessmentId').updateValueAndValidity();
    this.reportForm.get('selectedQB').updateValueAndValidity();
    this.reportForm.get('selectedAssessment').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
  }

  toggleValidation(){
    this.reportForm.get('fromDate').clearValidators();
    this.reportForm.get('toDate').clearValidators();
    this.reportForm.get('questionBankName').setValidators(Validators.required);
    this.reportForm.get('selectedQB').setValidators(Validators.required);
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').setValidators(Validators.required);
    this.reportForm.get('selectedAssessment').clearValidators();
    this.reportForm.get('assessmentId').clearValidators();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('questionBankName').updateValueAndValidity();
    this.reportForm.get('selectedQB').updateValueAndValidity();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('selectedAssessment').updateValueAndValidity();
    this.reportForm.get('assessmentId').updateValueAndValidity();
  }

  toggleValidationForUserAssessment(){
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').setValidators(Validators.required);
    this.reportForm.get('fromDate').setValidators(Validators.required);
    this.reportForm.get('toDate').setValidators(Validators.required);
    this.reportForm.get('questionBankName').clearValidators();
    this.reportForm.get('assessmentId').clearValidators();
    this.reportForm.get('selectedAssessment').clearValidators();
    this.reportForm.get('selectedQB').clearValidators();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('questionBankName').updateValueAndValidity();
    this.reportForm.get('assessmentId').updateValueAndValidity();
    this.reportForm.get('selectedAssessment').updateValueAndValidity();
    this.reportForm.get('selectedQB').updateValueAndValidity();
  }

  toggleValidationForUser(){
    this.reportForm.get('lob').setValidators(Validators.required);
    this.reportForm.get('subLob').setValidators(Validators.required);
    this.reportForm.get('fromDate').clearValidators();
    this.reportForm.get('toDate').clearValidators();
    this.reportForm.get('questionBankName').clearValidators();
    this.reportForm.get('selectedQB').clearValidators();
    this.reportForm.get('assessmentId').clearValidators();
    this.reportForm.get('selectedAssessment').clearValidators();
    this.reportForm.get('lob').updateValueAndValidity();
    this.reportForm.get('subLob').updateValueAndValidity();
    this.reportForm.get('fromDate').updateValueAndValidity();
    this.reportForm.get('toDate').updateValueAndValidity();
    this.reportForm.get('questionBankName').updateValueAndValidity();
    this.reportForm.get('selectedQB').updateValueAndValidity();
    this.reportForm.get('assessmentId').updateValueAndValidity();
    this.reportForm.get('selectedAssessment').updateValueAndValidity();
  }

  getAssessmentList(){
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    if(this.validateDate()&& this.reportForm.get('subLob').value){
      this.reportService.getAssessmentName(fromDate, toDate, this.reportForm.get('subLob').value.subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.snackBar.open('No Assessment available for selected date range and Sub-LOB', 'OK', {duration: snackBarDuration});
      }
      else{
        this.userAssessmentList = res;
        this.reportForm.get('assessmentId').setValidators(Validators.required);
        this.reportForm.get('selectedAssessment').setValidators(Validators.required);
        this.reportForm.get('assessmentId').updateValueAndValidity();
        this.reportForm.get('selectedAssessment').updateValueAndValidity();
      }
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        this.snackBar.open('Invalid Data!', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
    }else{
      this.loader.close();
    }
    
  }

  getQuestionBank(subLob){
    if(this.reportForm.get('reportType').value == 'Question Report'){
      this.questionBankList = [];
      this.reportForm.get('selectedQB').setValue([]);
      this.loader.open();
      this.reportService.getQuestionBank(subLob.subLobId)
      .subscribe(res => {
        
        if(res == 'ERROR'){
          this.loader.close();
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }else if(res == null){
          this.loader.close();
          this.showReport = true;
          this.snackBar.open('No Question Bank Available', 'OK', {duration: snackBarDuration});
        }
        else {
          this.loader.close();
          this.questionBankList = res;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }
  }

  getReport(reportType){
    this.rawDataReport = [];
    this.userAssessmentReport = [];
    if(reportType == 'Raw Data Report'){
      if(this.validateDate()){
        this.getRawDataReport();
      } 
    } else if(reportType == 'User Assessment Report'){
      if(this.validateDate()){
        this.getUserAssessmentReport();
      }
    } else if(reportType == 'Question Report'){
      this.getQuestionReport();
    } else if(reportType == 'User Report'){
      this.getUserReport();
    } else if(reportType == 'Summary Report'){
      if(this.validateDate()){
        this.getSummaryReport();
      }
    }
  }

  getSummaryReport(){
    // get Summarty data report
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    this.reportService.getSummaryDataReport(fromDate, toDate)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.summaryReport = this.createSummaryReportObj(res);
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  createSummaryReportObj(data){
    let obj = {
      User_Created: data.usersCreated,
      Assessment_Generated: data.assessmentGenerated,
      Total_Assessment_Taken: data.totalAssessmentTaken,
      Distinct_Users_who_have_Taken_Assessment: data.distinctUsersTakenAssessment
    }
    return obj;
  }

  getUserReport(){
    this.loader.open();
    let lobId = '';
    let subLobId = '';
    if(this.reportForm.get('lob').value && this.reportForm.get('subLob').value){
      lobId = this.reportForm.get('lob').value.lobId;
      subLobId = this.reportForm.get('subLob').value.subLobId;
    }
    if(lobId != '' && subLobId != ''){
      this.reportService.getUserReport(lobId, subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return;
        } else if(res == null){
          this.showReport = true;
        }
        else if(res != null && res != []){
          this.userReport = res;
          this.showReport = true;
        }
      }, err => {
        this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
      })
    }else{
      this.loader.close();
    }
  }

  setQuestionBankName(qb){
    this.reportForm.get('questionBankName').setValue(qb.questionBankName);
    this.questionReport = [];
    this.showReport = false;
  }

  getQuestionReport(){
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    if(this.reportForm.get('subLob').value){
      this.reportService.getQuestionReport(this.reportForm.get('questionBankName').value, this.reportForm.get('subLob').value.subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return;
        } else if(res == null){
          this.showReport = true;
        }
        else if(res != null && res != []){
          this.questionReport = res;
          this.showReport = true;
        }
        
      }, err => {
        this.loader.close();
        this.showReport = false;
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else {
      this.loader.close();
    }
  }

  getUserAssessmentReport(){
    // Get user assessmnet summary report
    this.loader.open();
    this.userAssessmentReport = [];
    if(this.reportForm.get('selectedAssessment').value){
      let assessmentId = this.reportForm.get('selectedAssessment').value.assessmentId;
      this.userAssessmentReport = [];
        this.reportService.getUserAssessmentReport(assessmentId)
        .subscribe( res => {
          this.loader.close();
          if(res == 'ERROR'){
            this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
            return;
          }
          else if(res == null){
            this.showReport = true;
            this.snackBar.open('No user records are available for selected assessment.', 'OK', {duration: snackBarDuration});
            this.userAssessmentList.forEach(assessment => {
              if(assessment.assessmentId == assessmentId){
                let obj = {
                  ...assessment,
                  rescheduledUserList: [],
                  nonRescheduledUserList: []
                }
                this.userAssessmentReport.push(obj);
              }
            })
          }
          else if(res != []){
            this.userAssessmentList.forEach(assessment => {
              if(assessment.assessmentId == assessmentId){
                let obj = this.getRescheduledAssessmentList(assessment, res);
                this.userAssessmentReport.push(obj);
              }
            })
            this.userList = res;
            this.showReport = true;
          }
          
        }, err => {
          this.loader.close();
          this.showReport = false;
          if(err.status == '401'){
            this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
            resetLocalStorage();
            this.router.navigate([appVariables.loginPageUrl]);
          }else{
            this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          }
        })  
    }else{
      this.snackBar.open('Please select Assessment Name.', 'OK', {duration: snackBarDuration});
    }
    
  }

  getRescheduledAssessmentList(assessment, userList:any){
    let obj = {
      ...assessment,
      rescheduledUserList: [],
      nonRescheduledUserList: []

    }
    userList.forEach(user => {
      if(user.rescheduleCount > 0){
        obj.rescheduledUserList.push(user);
      }else{
        obj.nonRescheduledUserList.push(user);
      }
    })
    return obj;
  }

  getRawDataReport(){
    // get raw data report
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.reportForm.get('fromDate').value, 'dd-MMM-yy');
    let toDate = new DatePipe('en-US').transform(this.reportForm.get('toDate').value, 'dd-MMM-yy');
    this.reportService.getRawDataReport(fromDate, toDate)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.showReport = true;
      }
      else if(res !== null && res != []){
        this.rawDataReport = res;
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  downloadReport(){
    let report = [];
    let assessmentData = [];
    let nonRescheduledUserData = [];
    let rescheduledUserData = [];
    if(this.reportForm.get('reportType').value == 'User Assessment Report'){
      this.userAssessmentReport.forEach(data => {
        assessmentData.push(this.createUserAssessmnetObj(data));
        if(data.nonRescheduledUserList.length > 0){
          data.nonRescheduledUserList.forEach(user => {
            nonRescheduledUserData.push(this.createUserQuizDetailObj(user));
          })
        }
        if(data.rescheduledUserList.length > 0){
          data.rescheduledUserList.forEach(user => {
            rescheduledUserData.push(this.createUserQuizDetailObj(user));
          })
        }
      })
      const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(assessmentData);  
      const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
      XLSX.utils.book_append_sheet(wb1, ws1, 'Assessment Details');
      
      const ws2: XLSX.WorkSheet = XLSX.utils.json_to_sheet(nonRescheduledUserData);  
      const wb2: XLSX.WorkBook = XLSX.utils.book_new(); 
      XLSX.utils.book_append_sheet(wb1, ws2, 'NonRescheduled User Details');

      const ws3: XLSX.WorkSheet = XLSX.utils.json_to_sheet(rescheduledUserData);  
      const wb3: XLSX.WorkBook = XLSX.utils.book_new(); 
      XLSX.utils.book_append_sheet(wb1, ws3, 'Rescheduled User Details');

      XLSX.writeFile(wb1, 'User Assessment Report.xlsx');

    }
    else if(this.reportForm.get('reportType').value == 'Question Report'){
      this.questionReport.forEach( data => {
        let obj = this.createQuestionReport(data);
        report.push(obj);
      })
      const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(report);  
      const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
      XLSX.utils.book_append_sheet(wb1, ws1, 'Question Details');
      XLSX.writeFile(wb1, 'Question Report.xlsx');

    } else if(this.reportForm.get('reportType').value == 'User Report'){
      this.userReport.forEach( data => {
        let obj = this.createUserReport(data);
        report.push(obj);
      })
      const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(report);  
      const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
      XLSX.utils.book_append_sheet(wb1, ws1, 'User Details');
      XLSX.writeFile(wb1, 'User Report.xlsx');
    } else if(this.reportForm.get('reportType').value == 'Summary Report'){
      for (const [key, value] of Object.entries(this.summaryReport)) {
        let obj = this.createSummaryData(key,value);
        report.push(obj);
      }
      const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(report, {skipHeader: true});
      const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
      XLSX.utils.book_append_sheet(wb1, ws1, 'Summary');
      XLSX.writeFile(wb1, 'Summary Report.xlsx');
    }
  }

  createSummaryData(key, value){
    let obj = {
      Parameter: key,
      Value: value
    };
    return obj; 
  }

  createUserReport(data){
    let obj = {
      "Employee Sap No": data.empSapNo,
      "Employee Name": data.employeeName,
      "Role": data.roles[0].role,
      "Gender": data.gender,
      "PSID": data.psid,
      "GDU": data.gdu,
      "Joining Date SSBJV": data.joiningDateSSBJV,
      "Designation": data.designationName,
      "Location": data.locationName,
      "RM Name": data.rmName,
      "RM Sap No": data.rmSapNo,
      "RM PSID": data.rmPsId,
      "Created On": data.createdOn,
      "Lob Name": data.lob ? data.lob.lobName : '',
      "Lob Status": data.lob ? data.lob.status: '',
      "SubLob Name": data.subLob ? data.subLob.subLobName: '',
      "SubLob Status": data.subLob ? data.subLob.status: '',
      "Employee Status": data.status
    }
    return obj;
  }

  createUserQuizDetailObj(user){
    let obj = {
      "Assessment Name": user.assessmentName,
      "User Id": user.userId,
      "User Name": user.userName,
      "Designation": user.designationName,
      "Location": user.location,
      "Quiz Id": user.quizId,
      "Set Id": user.setId,
      "Quiz Date": new DatePipe('en-US').transform(user.quizDate, 'dd-MM-yyyy'),
      "Total Duration": user.totalDuration,
      "Quiz Duration": user.quizDuration,
      "Passing Percent": user.passingPercent,
      "Total Marks": user.totalMarks,
      "Obtained Marks": user.obtainedMarks,
      "Obtained Percent": user.obtainedPercent,
      "Quiz Outcome": user.quizOutcome,
      //"Attempt Count": user.attemptCount
    }
    return obj;
  }

  createUserAssessmnetObj(data){
    let obj = {
      "Assessment Id": data.assessmentId,
      "Assessment Name": data.assessmentName,
      "Assessment Type": data.assessmentType,
      "Requestor Ecode": data.requestorEcode,
      "Requestor Name": data.requestorName,
      "Lob Name": data.subLob ? data.subLob.lob.lobName: '',
      "Lob Status": data.subLob ? data.subLob.lob.status: '',
      "SubLob Name": data.subLob ? data.subLob.subLobName: '',
      "SubLob Status": data.subLob ? data.subLob.status: '',
      "Completed Assessment": data.completedAssessment,
      "Created Date": new DatePipe('en-US').transform(data.createdDate, 'dd-MM-yyyy'),
      "Duration": data.duration,
      "Location": data.location,
      "Total Assessment": data.totalAssessment,
      "Fail Count": data.failCount,
      "Pass Count": data.passCount,
      "Pending Count": data.pendingCount,
    }
    return obj;
  }

  createQuestionReport(data){
    let obj = {
      "Qustion Bank Id": data._id,
      "Question Bank Name": data.questionBankName,
      "Question Bank Status": data.status,
      "Lob Name": data.subLob ? data.subLob.lob.lobName :'',
      "Lob Status": data.subLob ? data.subLob.lob.status : '',
      "SubLob Name": data.subLob ? data.subLob.subLobName : '', 
      "Sublob Status": data.subLob ? data.subLob.status: '',
      "Question Id": data.questionId,
      "Question Text": data.questionText,
      "Type": data.type,
      "Question Status": data.questionStatus,
      "Choice Number": data.choiceNumber,
      "Discriptive Answer": data.discriptiveAnswer,
      "Total Marks": data.totalMarks
    }
    if(data.optionList){
    for(let i =1; i <= data.optionList.length; i++){
      obj['Option' + i] = data.optionList[i-1].optionName;
      obj['Answer' + i] = data.optionList[i-1].answer;
    }
  }
    if(data.correctAnswer){
    for(let i = 1; i <= data.correctAnswer.length ; i++){
      obj['Correct Option' + i] = data.correctAnswer[i-1].optionName;
      obj['Correct Answer' + i] = data.correctAnswer[i-1].answer;
    }
  }

    return obj;
  }

  downloadRawDataReport(){
      let assessmentData = [];
      let userData = [];
      let questionData = [];
      if(this.rawDataReport.length > 0){
        this.rawDataReport.forEach(data => {
          assessmentData.push(this.createAssessmentData(data));
          if(data.userQuizDetail.length > 0) {
            data.userQuizDetail.forEach(user => {
              let obj = this.createUserData(user);
              let userAssessmentDetail = {
                "Question Bank Name": data.questionBankName,
                "Assessment Name": data.assessmentName,
                "Category": data.category,
                ...obj
              }
              userData.push(userAssessmentDetail);
              if(user.questionList.length >0){
                user.questionList.forEach(question => {
                  let flatQuestionObj = this.createQuestiondata(question);
                  let obj = {
                    'User Id': user.userId,
                    'Set Id' : user.questionSetId,
                    'Assessment Name' : data.assessmentName,
                    'Date' : user.quizDate,
                    ...flatQuestionObj
                }
                  questionData.push(obj);
                })
              }
            })
          }
        })
      }

    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(assessmentData);  
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Assessment Details');
    
    const ws2: XLSX.WorkSheet = XLSX.utils.json_to_sheet(userData);  
    const wb2: XLSX.WorkBook = XLSX.utils.book_new(); 
    XLSX.utils.book_append_sheet(wb1, ws2, 'User Details');

    const ws3: XLSX.WorkSheet = XLSX.utils.json_to_sheet(questionData);  
    const wb3: XLSX.WorkBook = XLSX.utils.book_new(); 
    XLSX.utils.book_append_sheet(wb1, ws3, 'Question Details');

    XLSX.writeFile(wb1, 'Raw Data Report.xlsx');
    
  }

  private createAssessmentData(data){
    let obj = {
      "Assessment Name": data.assessmentName,
      "Requestor Name": data.requestorName,
      "Requestor Ecode": data.requestorEcode,
      "Lob Name": data.subLob ? data.subLob.lob.lobName : '',
      "Lob Status": data.subLob ? data.subLob.lob.status : '',
      "SubLob Name": data.subLob ? data.subLob.subLobName : '',
      "SubLob Status": data.subLob ? data.subLob.status : '',
      "Category": data.category,
      "Course Name": data.courseName,
      "Duration": data.duration,
      "Location": data.location,
      "NO Of Attempts": data.noOfAttempts,
      "NO Of Question To Display": data.noOfQuestionToDisplay,
      "Passing Percent": data.passingPercent,
      "Purpose": data.purpose,
      "Requestor DU": data.requestorDu,
      "Question Bank Name": data.questionBankName,
      "Assessment Created Date": data.assessmentCreatedDate,
      "Assessment Completion Date": data.assessmentCompletionDate
    }
    return obj;
  }

  private createUserData(user){
    let obj = {
      "User Id": user.userId,
      "Employee Name": user.employeeName,
      "Designation": user.designationName,
      "Location": user.locationName,
      "Question Set Id": user.questionSetId,
      "Quiz Date": user.quizDate,
      "Has Discriptive Question": user.hasDiscriptiveQuestion,
      "Attempted Question": user.attemptedQuestion,
      "Correct Question": user.correctQuestion,
      "Wrong Question": user.wrongQuestion,
      "Quiz Score": user.quizScore,
      "Quiz Outcome": user.quizOutcome,
      "Quiz Duration": user.quizDuration,
    }
    return obj;
  }

  private createQuestiondata(question){
    let obj = {
      "Question Id": question.questionId,
      "Type": question.type,
      "Status": question.status,
      "Choice Number": question.choiceNumber,
      "Discriptive Answer": question.discriptiveAnswer,
      "Obtained Marks": question.obtainedMarks,
      //attempt_count: question.attemptCount,
      "Question Result": question.questionResult,
      "Total Marks": question.totalMarks,
      "Question Text": question.questionText,
    }

    if(question.optionList != null){
      for(let i =1; i <= question.optionList.length; i++){
        obj['Option' + i] = question.optionList[i-1].optionName;
        obj['Answer' + i] = question.optionList[i-1].answer;
      }
    }
    if(question.correctAnswer != null){
      for(let i = 1; i <= question.correctAnswer.length ; i++){
        obj['Correct Option' + i] = question.correctAnswer[i-1].optionName;
        obj['Correct Answer' + i] = question.correctAnswer[i-1].answer;
      }
    }
    if(question.selectedAnswer != null){
      for(let i =1; i <= question.selectedAnswer.length ; i++){
        obj['Selected Option' + i] = question.selectedAnswer[i-1].optionName;
        obj['Selected Answer' + i] = question.selectedAnswer[i-1].answer;
      }
    }
    return obj;
  }


}
