import { Component, OnInit, Output, EventEmitter, Inject, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { AdminService } from '../../../admin.service';
import { MatSnackBar, MAT_DIALOG_DATA, MatDialogRef, MatDialog } from '@angular/material';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables, stringPattern, digitPattern, appAssessmentFrequency } from '../../../../../app.constants';
import { DatePipe } from '@angular/common';
import { DialogData } from '../../../../quiz/question-set/question-set.component';
import * as XLSX from 'xlsx';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-view-assessment',
  templateUrl: './view-assessment.component.html',
  styleUrls: ['./view-assessment.component.scss']
})
export class ViewAssessmentComponent implements OnInit {

  public assessmentFilterForm:FormGroup;
  public minDate:Date;
  public maxDate:Date;
  public currentPage = 1;
  public itemsPerPage = 6;
  public lobConfig;
  public subLobConfig;
  public lobList = [];
  public subLobList = [];
  public assessmentList = [];
  public showAssessmentList = false;

  @Output() newItemEvent = new EventEmitter<number>();

  constructor(
    private loader: AppLoaderService,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private router: Router,
    private fb: FormBuilder,
    public dialog: MatDialog
  ) {
    const currentYear = new Date().getFullYear();
    this.minDate = new Date(currentYear - 20, 0, 1);
    this.maxDate = new Date();
    this.lobConfig = {
      displayKey:"lobName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.lobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      displayKey:"subLobName",
      search:true,
      height: '200px',
      placeholder:'Select',
      customComparator: ()=>{},
      limitTo: this.subLobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'subLobName'
    }
   }

   sendMessage(value) {
    this.newItemEvent.emit(value)
  }

  ngOnInit() {
    this.createAssessmentFilterForm();
    this.getAllLob();
  }

  createAssessmentFilterForm(){
    this.assessmentFilterForm = this.fb.group({
      fromDate: [{value: '', disabled: false}, Validators.required],
      toDate: [{value: '', disabled: false}, Validators.required],
      lob: [null, Validators.required],
      subLob : [null, Validators.required]
    })
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.lobList = res;
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLobList(){
    this.loader.open();
    this.showAssessmentList = false;
    this.assessmentList = [];
    this.assessmentFilterForm.get('subLob').setValue([]);
    this.subLobList = [];
    if(this.assessmentFilterForm.get('lob').value){
      this.adminService.getSubLob(this.assessmentFilterForm.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        } else if(err.status == '404'){
          this.snackBar.open('No Sub Lob found for selected LOB', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
  }

  validateDate(){
    let fromDate = new DatePipe('en-US').transform(this.assessmentFilterForm.get('fromDate').value, 'yyyy-MM-dd');
    let toDate = new DatePipe('en-US').transform(this.assessmentFilterForm.get('toDate').value, 'yyyy-MM-dd');
    if(fromDate > toDate){
      this.snackBar.open('Start date cannot be greater then end date.', 'OK', {duration: snackBarDuration});
      return false;
    }else{
      return true;
    }
  }

  getAssessmentList(){
    this.loader.open();
    let fromDate = new DatePipe('en-US').transform(this.assessmentFilterForm.get('fromDate').value, 'yyyy-MMM-dd');
    let toDate = new DatePipe('en-US').transform(this.assessmentFilterForm.get('toDate').value, 'yyyy-MMM-dd');
    if(this.validateDate() &&  this.assessmentFilterForm.get('subLob').value){
      this.adminService.getAssessmentForEdit(fromDate, toDate, this.assessmentFilterForm.get('subLob').value.subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.showAssessmentList = true;
          this.snackBar.open('Assessment not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.assessmentList = res;
          this.showAssessmentList = true;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        } else if(err.status == '404'){
          this.showAssessmentList = true;
          this.snackBar.open('No Assessment found for selected Search Criteria', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
  }

  createEditObj(assessmentData){
    let obj = {
        assessmentId: assessmentData.assessmentId,
        assessmentName: assessmentData.assessmentName,
        type: assessmentData.assessmentType,
        userIds: [],
        rescheduleCount: 0,
        active: false
    }
    return obj;
  }

  deactivateAssessment(assessmentData){
    this.loader.open();
    let data = this.createEditObj(assessmentData);
      this.adminService.editAssessmentDetails(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Assessment Deactivated successfully', 'OK', {duration: snackBarDuration});
        this.getAssessmentList();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
        
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  openDialog(assessmentData): void {
    const dialogRef = this.dialog.open(EditAssessmentDialogComponent, {
      width: '1100px',
      height: '650px',
      data: {data: assessmentData}
    });

    dialogRef.afterClosed().subscribe(result => {
    });  
  }
}

@Component({
  selector: 'app-edit-assessment-dialog',
  templateUrl: './edit-assessment-dialog.html',
  styleUrls: ['./view-assessment.component.scss']
})
export class EditAssessmentDialogComponent implements OnInit {

  @ViewChild('userFile', { static: false }) userFile: ElementRef;

  public assessmentData;
  public assessmentForm: FormGroup;
  public frequencyList = appAssessmentFrequency;
  public arrayBuffer:any;
  public file:File;
  public receivedData;
  public updateAssessmentData;
  public isCheckedReschedule = false;
  public failedUserList = [];
  public failedUserObjList = [];
  public selectedFailedUsers: string[] = [];
  public dropdownSettings:IDropdownSettings = {};

  public failedUsers = new FormControl();

  constructor(
    public dialogRef: MatDialogRef<EditAssessmentDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private loader: AppLoaderService,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private router: Router,
    private fb: FormBuilder
  ) {
    this.receivedData = data;
    this.assessmentData = this.receivedData.data;
    //this.failedUserList = this.receivedData.failedUserList
    this.updateAssessmentData = {...this.assessmentData};
  }

  ngOnInit() {
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'id',
      textField: 'name',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 6,
      allowSearchFilter: true
    };
    this.getFailedUserList(this.assessmentData.assessmentId);
    this.createAssessmentform(this.assessmentData);
    //this.disableUserUpload(this.assessmentData);
  }

  getFailedUserList(assessmentId){
    this.loader.open();
    this.adminService.getFailedUserList(assessmentId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Failed Users Not Found', 'OK', {duration: snackBarDuration});
      }else{
        this.failedUserList = res;
        this.createFailedUserListObj();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      } else if(err.status == '404'){
        //this.openDialog(assessmentData, failUserList);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        //this.openDialog(assessmentData, failUserList);
      }
    })
  }

  createFailedUserListObj(){
    this.failedUserList.forEach(user => {
      let tempArray = user.split('-');
      let obj = {
        id:tempArray[1],
        name: tempArray[1] + ' ' + tempArray[0]
      }
      this.failedUserObjList.push(obj);
    })
  }

  onItemSelect(user: any) {
    this.selectedFailedUsers.push(user.id);
  }
  onSelectAll(user: any) {
    this.failedUserObjList.forEach(user => {
      this.selectedFailedUsers.push(user.id);
    })
  }

  onItemDeSelect(user:any){
    this.selectedFailedUsers = this.selectedFailedUsers.filter(id => id != user.id);
  }

  onUnSelectAll(user:any){
    this.selectedFailedUsers = [];
  }

  createAssessmentform(assessment){
    let dateStr = assessment.createdDate.replace(/-/g,' ');
    this.assessmentForm = this.fb.group({
      requestorName: [assessment.requestorName || ''],
      requestorEcode: [assessment.requestorEcode || ''],
      category: [assessment.category || ''],
      frequency: [assessment.frequency || ''],
      creationDate: [new Date(dateStr) || ''],
      purpose: [assessment.purpose || ''],
      questionBankName: [assessment.questionBankName.questionBankName || ''],
      lob: [assessment.subLob.lob.lobName || ''],
      subLob: [assessment.subLob.subLobName || ''],
      noOfQuestionToDisplay: [assessment.noOfQuestionToDisplay || ''],
      passingPercent: [assessment.passingPercent || ''],
      noOfAttempts: [assessment.noOfAttempts || ''],
      duration: [assessment.duration || ''],
      assessmentName: [assessment.assessmentName || ''],
      userList: [[]],
      assessmentType: [assessment.assessmentType || ''],
      trainingBatch: [assessment.trainingBatch != null ? assessment.trainingBatch.trainingBatchName: null]
    })
  }

  parseFile(event){
    if(event.target.files.length > 0) {
      this.file= event.target.files[0]; 
      let fileReader = new FileReader();
      let parsedFile = [];
      let userArray = [];
      fileReader.onload = (e) => {
        this.arrayBuffer = fileReader.result;
        let data = new Uint8Array(this.arrayBuffer);
        let arr = new Array();
        for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
        let bstr = arr.join("");
        let workbook = XLSX.read(bstr, {type:"binary"});
        let first_sheet_name = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[first_sheet_name];
        parsedFile = XLSX.utils.sheet_to_json(worksheet,{raw:true});
        parsedFile.forEach(user => {
          var values = Object.keys(user).map(function(e) {
            userArray.push(...user[e]);
          })
        });
        this.assessmentForm.get('userList').setValue(userArray);
        this.updateAssessmentData.userIds = userArray;
      }
      fileReader.readAsArrayBuffer(this.file);
    }else{
      this.assessmentForm.get('userList').setValue('');
      this.updateAssessmentData.userIds = [];
    }
  }

  validateUserIds(userIds){
    let valid = true;
    if(userIds.length >= 1){
      userIds.forEach(id => {
        if(!id.toString().match(digitPattern) || id.toString().length < 8 || id.toString.length > 8){
            this.snackBar.open('Invalid / Missing data in file.', 'OK', {duration: snackBarDuration});
            valid = false;
        }else{
          valid = true;
        }
      })
    }else if(this.assessmentForm.get('trainingBatch').value != null){
      valid = true;
    }
    else{
      this.snackBar.open('File is empty.', 'OK', {duration: snackBarDuration});
      valid = false;
    }
    return valid;
  }

  createEditObj(assessmentData){
    let obj = {
        assessmentId: assessmentData.assessmentId,
        assessmentName: assessmentData.assessmentName,
        type: assessmentData.assessmentType,
        userIds: [],
        rescheduleCount: 0,
        active: true,
        trainingBatch: assessmentData.trainingBatch
    }
    if(this.isCheckedReschedule){
        obj.userIds = this.selectedFailedUsers;
        obj.rescheduleCount = 1;
      }else{
        obj.userIds = this.assessmentForm.get('userList').value;
        obj.rescheduleCount = 0;
      }
    return obj;
  }

  updateAssessment(){
    this.loader.open();
    let data = this.createEditObj(this.updateAssessmentData);
    if(this.validateUserIds(data.userIds)){
      this.adminService.editAssessmentDetails(data)
      .subscribe(res => {
        this.loader.close();
        this.snackBar.open('Assessment Updated Successfully.', 'OK', {duration: snackBarDuration});
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
      this.snackBar.open('Invalid User Id List', 'OK', {duration: snackBarDuration});
    }
  }
}
