import { Component, OnInit, ViewChild, ElementRef, ChangeDetectorRef } from '@angular/core';
import { appLocationList, localStorageVariables, appSessionErr, appGenericErr, appVariables, resetLocalStorage, snackBarDuration, stringPattern, appAssessmentType } from '../../../../../app.constants';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import * as XLSX from 'xlsx';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from "@angular/material";
import { digitPattern } from '../../../../../app.constants';
import { Router } from '@angular/router';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';

@Component({
  selector: 'app-add-assessment',
  templateUrl: './add-assessment.component.html',
  styleUrls: ['./add-assessment.component.scss']
})
export class AddAssessmentComponent implements OnInit {

  @ViewChild('userFile', { static: false }) userFile: ElementRef;

  public locationList = appLocationList;
  public categoryList = [];
  public categoryConfig;
  public addAssessmentForm : FormGroup;
  public arrayBuffer:any;
  public file:File;
  public questionBankList = [];

  public userInfo;
  public isDisabled = false;

  public lobList = [];
  public subLobList = [];
  public trainingBatchList = [];
  public lobConfig;
  public subLobConfig;
  public trainingBatchConfig;
  public config;
  public topicList = [];
  public topicConfig;
  public assessmentTypeList = appAssessmentType;

  constructor( 
    private fb: FormBuilder,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private router: Router,
    private loader: AppLoaderService
    ) { 
      this.config = {
        displayKey:"questionBankName", //if objects array passed which key to be displayed defaults to description
        search:true,//true/false for the search functionlity defaults to false,
        height: '200px', //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
        placeholder:'Select', // text to be displayed when no item is selected defaults to Select,
        customComparator: ()=>{}, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
        limitTo: this.questionBankList.length, // a number thats limits the no of options displayed in the UI similar to angular's limitTo pipe
        moreText: 'more', // text to be displayed whenmore than one items are selected like Option 1 + 5 more
        noResultsFound: 'No results found! (Please make sure you have selected sub-LOB)', // text to be displayed when no items are found while searching
        searchPlaceholder:'Search', // label thats displayed in search input,
        searchOnKey: 'questionBankName' // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
        }
        this.lobConfig = {
          displayKey:"lobName",
          search:true,
          height: '200px',
          placeholder:'Select',
          customComparator: ()=>{},
          limitTo: this.lobList.length,
          moreText: 'more',
          noResultsFound: 'No results found!',
          searchPlaceholder:'Search',
          searchOnKey: 'lobName'
        }
        this.subLobConfig = {
          displayKey:"subLobName",
          search:true,
          height: '200px',
          placeholder:'Select',
          customComparator: ()=>{},
          limitTo: this.subLobList.length,
          moreText: 'more',
          noResultsFound: 'No results found! (Please make sure you have selected LOB)',
          searchPlaceholder:'Search',
          searchOnKey: 'subLobName'
        }
  this.categoryConfig = {
    displayKey:"categoryName",
    search:true,
    height: '200px',
    placeholder:'Select',
    customComparator: ()=>{},
    limitTo: this.categoryList.length,
    moreText: 'more',
    noResultsFound: 'No results found!',
    searchPlaceholder:'Search',
    searchOnKey: 'categoryName'
  }
  this.trainingBatchConfig = {
    displayKey:"trainingBatchName",
    search:true,
    height: '200px',
    placeholder:'Select Training Batch',
    customComparator: ()=>{},
    limitTo: this.trainingBatchList.length,
    moreText: 'more',
    noResultsFound: 'No results found! (Please make sure you have selected SUB LOB)',
    searchPlaceholder:'Search',
    searchOnKey: 'trainingBatchName'
  };
  this.topicConfig = {
    displayKey:"topicName",
    search:true,
    height: '200px',
    placeholder:'Select',
    customComparator: ()=>{},
    limitTo: this.topicList.length,
    moreText: 'more',
    noResultsFound: 'No results found!',
    searchPlaceholder:'Search',
    searchOnKey: 'topicName'
  }
}

  ngOnInit() {
    this.userInfo = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
    this.createAssessmentForm();
    this.getAllCategory();
    this.getAllLob();
    //this.getQuesionBank();
    this.checkDisable();
  }

  createAssessmentForm(){
    this.addAssessmentForm = this.fb.group({
      requestorName: [this.userInfo.userName || ''],
      requestorEcode: [this.userInfo.userDetail.username || ''],
      category: [[], [Validators.required]],
      topic: [[]],
      assessmentType: [null],
      purpose: [''],
      questionBankName: [''],
      lob: [[], Validators.required],
      subLob: [[], Validators.required],
      questionBank: [[], [Validators.required]],
      trainingBatch: [[]],
      noOfQuestionToDisplay: ['', [Validators.required, Validators.pattern(digitPattern)]],
      passingPercent: ['', [Validators.required, Validators.pattern(digitPattern)]],
      noOfAttempts: ['', [Validators.required, Validators.pattern(digitPattern)]],
      duration: ['', [Validators.required, Validators.pattern(digitPattern)]],
      assessmentName: ['', [Validators.required]],
      userIds: [[], [Validators.required]],
      allUsers: [false]
    })
  }

  disableUserListUpload(){
    if(this.addAssessmentForm.get('allUsers').value == true){
      this.userFile.nativeElement.disabled = true;
      this.addAssessmentForm.get('userIds').setValue([]);
      this.addAssessmentForm.get('userIds').clearValidators();
      this.addAssessmentForm.get('userIds').updateValueAndValidity();
      if(this.userFile){
        this.userFile.nativeElement.value = null;
      }
    } 
    else{
      this.userFile.nativeElement.disabled = false;
      this.addAssessmentForm.get('userIds').setValidators(Validators.required);
      this.addAssessmentForm.get('userIds').updateValueAndValidity();
    }
  }

  checkDisable(){
    if(this.questionBankList.length <= 0){
      this.isDisabled = true;
    }else{
      this.isDisabled = false;
    }
  }

  getAllCategory(){
    this.loader.open();
    this.adminService.getAllCategory()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Category not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.categoryList = this.removeSpecialCharacterFromStr(res);
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('No Category Found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  removeSpecialCharacterFromStr(res){
    let strArr = res;
    strArr.forEach(obj => {
      if (obj.categoryName.indexOf('_') > -1){
        let s = obj.categoryName.replace(/_/g, ' ');
        obj.categoryName = s;
      }
    })
    return strArr;
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          // let tempArray = []; 
          // res.forEach(lob => {
          //   if(lob.lobName != 'GENERIC'){
          //     tempArray.push(lob);
          //   }
          // })
          // this.lobList = tempArray;
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '403'){
        this.snackBar.open('Invalid logged in user', 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLob(lob){
    this.loader.open();
    this.addAssessmentForm.get('subLob').setValue([]);
    this.subLobList = [];
    this.addAssessmentForm.get('trainingBatch').setValue([]);
    this.addAssessmentForm.get('questionBank').setValue([]);
    this.questionBankList = [];
    this.trainingBatchList = [];
    if(lob){
      this.adminService.getSubLob(lob.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
    
  }

  getTrainingBatchList(){
    this.loader.open();
    this.trainingBatchList = [];
    this.addAssessmentForm.get('trainingBatch').setValue([]);
    let subLobId = this.addAssessmentForm.get('subLob').value.subLobId;
    this.adminService.getTrainingBatchBySubLob(subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Training Batch not found for selected Sub LOB.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.trainingBatchList = res;
        }
        this.trainingBatchConfig.limitTo = this.trainingBatchList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Training Batch not found for selected Sub LOB.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  toggleUserIdValidation(){
    let lob = this.addAssessmentForm.get('lob').value;
    if(lob.lobName == 'GENERIC'){
      this.addAssessmentForm.get('userIds').clearValidators();
      this.addAssessmentForm.get('userIds').updateValueAndValidity();
    }
    else{
      this.userFile.nativeElement.disabled = false;
      this.addAssessmentForm.get('userIds').setValidators(Validators.required);
      this.addAssessmentForm.get('userIds').updateValueAndValidity();
    }
  }

  toggleCategoryValidation(){
    let hasTopic = this.addAssessmentForm.get('category').value.hasTopic;
    if(hasTopic == true){
      this.addAssessmentForm.get('topic').setValue([]);
      this.addAssessmentForm.get('assessmentType').setValue(null);
      this.addAssessmentForm.get('topic').setValidators(Validators.required);
      this.addAssessmentForm.get('topic').updateValueAndValidity();
      this.addAssessmentForm.get('assessmentType').setValidators(Validators.required);
      this.addAssessmentForm.get('assessmentType').updateValueAndValidity();
      this.getTopicByCategoryId(this.addAssessmentForm.get('category').value.id);
    }else{
      this.addAssessmentForm.get('topic').setValue([]);
      this.addAssessmentForm.get('assessmentType').setValue(null);
      this.addAssessmentForm.get('topic').clearValidators();
      this.addAssessmentForm.get('topic').updateValueAndValidity();
      this.addAssessmentForm.get('assessmentType').clearValidators();
      this.addAssessmentForm.get('assessmentType').updateValueAndValidity();
    }
  }

  getTopicByCategoryId(categoryId){
    this.loader.open();
    this.topicList = [];
    this.addAssessmentForm.get('topic').setValue([]);
    this.adminService.getTopicByCategoryId(categoryId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Topics not found for selected Category.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.topicList = res;
        }
        this.topicConfig.limitTo = this.topicList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Topics not found for selected Category.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  trainingBatchSelected(){
    this.userFile.nativeElement.disabled = this.addAssessmentForm.get('trainingBatch').value != undefined ? true : false;
    this.addAssessmentForm.get('allUsers').setValue(false);
    this.addAssessmentForm.get('userIds').setValue([]);
    this.addAssessmentForm.get('userIds').clearValidators();
    this.addAssessmentForm.get('userIds').updateValueAndValidity();
    this.addAssessmentForm.get('allUsers').clearValidators();
    this.addAssessmentForm.get('allUsers').updateValueAndValidity();
    if(this.userFile){
      this.userFile.nativeElement.value = null;
    }
    if(this.addAssessmentForm.get('lob').value.lobName != 'GENERIC' && !this.userFile.nativeElement.disabled){
      this.addAssessmentForm.get('userIds').setValidators(Validators.required);
      this.addAssessmentForm.get('userIds').updateValueAndValidity();
    }
  }

  getQuestionBank(subLob){
    this.loader.open();
    this.questionBankList = [];
    this.addAssessmentForm.get('questionBank').setValue([]);
    if(subLob){
      this.adminService.getQuestionBank(subLob.subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('Question Banks not found for selected Sub-LOB.', 'OK', {duration: snackBarDuration});
        }else{
          this.questionBankList = res;
          this.config.limitTo = this.questionBankList.length;
          this.checkDisable();
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
    
  }

  parseFile(event){
    if(event.target.files.length > 0) {
      this.file= event.target.files[0]; 
      let fileReader = new FileReader();
      let parsedFile = [];
      let userArray = [];
      fileReader.onload = (e) => {
        this.arrayBuffer = fileReader.result;
        let data = new Uint8Array(this.arrayBuffer);
        let arr = new Array();
        for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
        let bstr = arr.join("");
        let workbook = XLSX.read(bstr, {type:"binary"});
        let first_sheet_name = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[first_sheet_name];
        parsedFile = XLSX.utils.sheet_to_json(worksheet,{raw:true});
        parsedFile.forEach(user => {
          var values = Object.keys(user).map(function(e) {
            userArray.push(...user[e]);
          })
        });
        this.addAssessmentForm.get('userIds').setValue(userArray);
      }
      fileReader.readAsArrayBuffer(this.file);
    }else{
      this.addAssessmentForm.get('userIds').setValue('');
    }
  }

  createAssessmentData(){
    if(this.validateUserIds()){
      let category = this.addAssessmentForm.get('category').value.categoryName.replace(/ /g,'_');
      let topic = this.addAssessmentForm.get('topic').value.topicName;
      let assessmentType = this.addAssessmentForm.get('assessmentType').value;
      let data = {
        requestorName: this.addAssessmentForm.get('requestorName').value,
        requestorEcode: this.addAssessmentForm.get('requestorEcode').value,
        assessmentName: this.addAssessmentForm.get('assessmentName').value,
        subLob: this.addAssessmentForm.get('subLob').value,
        questionBankName: this.addAssessmentForm.get('questionBank').value.questionBankName,
        category: category,
        assessmentTopic: topic,
        assessmentSubType: assessmentType,
        duration: this.addAssessmentForm.get('duration').value,
        noOfAttempts: this.addAssessmentForm.get('noOfAttempts').value,
        noOfQuestionToDisplay: this.addAssessmentForm.get('noOfQuestionToDisplay').value,
        passingPercent: this.addAssessmentForm.get('passingPercent').value,
        purpose: this.addAssessmentForm.get('purpose').value ? this.addAssessmentForm.get('purpose').value : '',
        userIds: this.addAssessmentForm.get('userIds').value,
        allUsers: this.addAssessmentForm.get('allUsers').value,
        trainingBatch: this.addAssessmentForm.get('trainingBatch').value != undefined ? this.addAssessmentForm.get('trainingBatch').value : null
      }
      this.addAssessment(data);
    }else{
      this.snackBar.open('Invalid User Id List', 'OK', {duration: snackBarDuration});
    }
    
  }

  private addAssessment(data){
    this.loader.open();
      this.adminService.addAssessmentDetails(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Assessment added successfully', 'OK', {duration: snackBarDuration});
       this.resetAssessForm();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
        
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  
  validateUserIds(){
    let valid = true;
    if(this.addAssessmentForm.get('lob').value.lobName != 'GENERIC'){
     
    if(this.addAssessmentForm.get('userIds').value.length >= 1){
      this.addAssessmentForm.get('userIds').value.forEach(id => {
        if(!id.toString().match(digitPattern) || id.toString().length < 8 || id.toString.length > 8){
            this.snackBar.open('Invalid / Missing data in file.', 'OK', {duration: snackBarDuration});
            valid = false;
        }else{
          valid = true;
        }
      })
    }
  }else if(this.addAssessmentForm.get('lob').value.lobName == 'GENERIC'){
    valid = true;
  }else{
      this.snackBar.open('File is empty.', 'OK', {duration: snackBarDuration});
      valid = false;
    }

    return valid;
  }

  resetAssessForm(){
    this.createAssessmentForm();
    this.addAssessmentForm.get('requestorName').setValue(this.userInfo.userName);
    this.addAssessmentForm.get('requestorEcode').setValue(this.userInfo.userDetail.username);
    if(this.userFile){
      this.userFile.nativeElement.value = null;
    }
  }

}
