import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseService } from '../../shared/services/base.service';
import { appApiPaths, localStorageVariables } from '../../app.constants';
import { SharedService } from '../../shared/shared.service';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(
    private baseService: BaseService,
    private sharedService: SharedService
  ) { }

  getQuestionBank(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionBank + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAllQuestionBank(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllQuestionBank + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  updateQuestionBank(data): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.put(appApiPaths.updateQuestionBank, data, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addAssessmentDetails, assessmantData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addAutoAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addAutoAssessmentDetails, assessmantData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addQuestion(questionData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addQuestion, questionData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getUserById(userId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getUserById + userId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
          }); 
  }

  getRole(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getRole, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  updateUser(userData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.put(appApiPaths.updateUser, userData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  addUser(userData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addUser, userData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getDescriptiveAssessment(userId, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getDescriptiveAssessment + userId + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getDescriptiveQuestion(assessmentId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getDescriptiveQuestion + assessmentId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  saveDescriptiveQuestion(questonData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveDescriptiveQuestion, questonData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getQuestionById(questionBnakName, subLobId, questionId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionById + questionBnakName +'&subLobId='+ subLobId + '&questionId=' + questionId , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getQuestions(questionBnakName, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestions + questionBnakName +'&subLobId='+ subLobId , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  updateQuestion(questonData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.updateQuestion, questonData , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getAllLob(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllLob , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getSubLob(lobName): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getSubLob + lobName , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  saveLob(lobData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveLob, lobData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  saveSubLob(subLobData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveSubLob, subLobData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  saveCategory(categoryData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveCategory, categoryData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getAllCategory(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllCategory, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAssessmentForEdit(fromDate, toDate, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAssessmentForEdit + fromDate + '&endDate=' + toDate + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  editAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.editAssessmentDetails, assessmantData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getFailedUserList(assessmantId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getFailedUserList + assessmantId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  createTrainingPlan(trainingPlanData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.createTrainingPlan, trainingPlanData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingPlan(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTrainingPlan + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  deactivateTrainingPlan(trainingPlanData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.deactivateTrainingPlan, trainingPlanData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  createTrainingBatch(trainingBatchData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.createTrainingBatch, trainingBatchData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingBatch(startDate, endDate): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTrainingBatch + startDate + '&endDate=' + endDate, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  editTrainingBatch(trainingBatchData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.editTrainingBatch, trainingBatchData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getUserByRole(role): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getUserByRole+ role, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingBatchForAttendanceCoverage(startDate, endDate, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTrainingBatchForAttendanceCoverage + startDate + '&endDate=' + endDate + '&subLobId=' + subLobId , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTraineesAttendance(trainingDate, trainingBatchId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTraineesAttendance + trainingDate + '&trainingBatchId=' + trainingBatchId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  saveTrainingBatchAttendance(attendanceData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveTrainingBatchAttendance, attendanceData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  saveTrainingBatchSchedule(trainingScheduleData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveTrainingBatchSchedule, trainingScheduleData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingBatchSchedule(trainingPlanId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTrainingBatchSchedule + trainingPlanId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingBatchBySubLob(subLobId, triggerDate?:any): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getTrainingBatchBySubLob + subLobId + '&triggerDate=' + '';
    if(triggerDate){
      url = url + triggerDate;
    }
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getBatchSpecificReport(trainingBatchId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getBatchSpecificReport + trainingBatchId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTopicByCategoryId(categoryId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTopicByCategoryId + categoryId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getUserList(lobId, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getUserListByLob + lobId + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getScoreCardDetails(userId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getScoreCardDetails + userId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }
}
