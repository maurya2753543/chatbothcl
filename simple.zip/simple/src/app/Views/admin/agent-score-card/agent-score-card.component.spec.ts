import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentScoreCardComponent } from './agent-score-card.component';

describe('AgentScoreCardComponent', () => {
  let component: AgentScoreCardComponent;
  let fixture: ComponentFixture<AgentScoreCardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentScoreCardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentScoreCardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
