import { Component, OnInit } from '@angular/core';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { AdminService } from '../admin.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { resetLocalStorage, appSessionErr, snackBarDuration, appVariables, appGenericErr, appUnauthorizedErr, getBrowserName, appAssessmentType, testData } from '../../../app.constants';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';

@Component({
  selector: 'app-agent-score-card',
  templateUrl: './agent-score-card.component.html',
  styleUrls: ['./agent-score-card.component.scss']
})
export class AgentScoreCardComponent implements OnInit {

  margins = {
    top: 70,
    bottom: 40,
    left: 30,
    width: 550
  };

  public lob;
  public lobList = [];
  public lobConfig;
  public subLob;
  public subLobList = [];
  public subLobConfig;
  public user;
  public userList = [];
  public userListConfig;
  public scoreCardDetails;
  public showPreviewFlag = false;
  public overallPercentage = 0;
  public classification = '';

  constructor(
    private loader: AppLoaderService,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private router: Router
  ) { 
    this.lobConfig = {
      displayKey:"lobName",
      search:true,
      height: '200px',
      placeholder:'Select LOB',
      customComparator: ()=>{},
      limitTo: this.lobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      displayKey:"subLobName",
      search:true,
      height: '200px',
      placeholder:'Select Sub LOB',
      customComparator: ()=>{},
      limitTo: this.subLobList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'subLobName'
    }
    this.userListConfig = {
      displayKey:"user",
      search:true,
      height: '200px',
      placeholder:'Select User',
      customComparator: ()=>{},
      limitTo: this.userList.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search',
      searchOnKey: 'user'
    }
  }

  ngOnInit() {
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.loader.close();
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.loader.close();
        this.lobList = res;
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('No LOB Found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLob(){
    this.loader.open();
    this.subLob = [];
    this.subLobList = [];
    this.userList = [];
    this.user = [];
    this.showPreviewFlag = false;
    if(this.lob){
      this.adminService.getSubLob(this.lob.lobName)
      .subscribe(res => {
        if(res == 'ERROR'){
          this.loader.close();
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.loader.close();
          this.snackBar.open('Sub LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.loader.close();
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('No Sub LOB found for selected LOB.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
  }

  getUserList(){
    this.loader.open();
    let lobId = this.lob.lobId;
    let subLobId = this.subLob.subLobId;
    this.userList = [];
    this.adminService.getUserList(lobId, subLobId)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.loader.close();
        this.snackBar.open('User List not found.', 'OK', {duration: snackBarDuration});
      }else if (res.length > 0){
        this.loader.close();
        res.forEach(resObj => {
          let obj = {
            user: resObj.userId + ' - ' + resObj.userName,
            ...resObj
          }
          this.userList = [...this.userList, obj];
        })
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('No User List Found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getUserScoreCardDetails(){
    this.loader.open();
    this.adminService.getScoreCardDetails(this.user.userId)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.showPreviewFlag = false;
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.loader.close();
        this.showPreviewFlag = false;
        this.snackBar.open('Score Card Details not found for User: ' + this.user.userId, 'OK', {duration: snackBarDuration});
      }else{
        this.loader.close();
        this.scoreCardDetails = res;
        this.setData();
      }
    }, err => {
      this.loader.close();
      this.showPreviewFlag = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Score Card Details not found for User: ' + this.user.userId, 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  setData(){
    this.showPreviewFlag = true;
    let count = 0;
    let overallScore = 0;
    let overallTotalScore = 0;
    for(var category of this.scoreCardDetails.catDetail) {
      category['name'] = category._id.replace(/_/g,' ');
      category['divWidth'] = 100;
      if(category._id === 'PROCESS_TRAINING'){
        category.divWidth = 60;
      }
      category['topicScore'] = [];
      category['avgScore'] = '';
      category['avgTotalScore'] = '';

      category.topicList.forEach(topic => {
        let obj = {
          topicName: topic,
          preAssessmentScore: '',
          postAssessmentScore: '',
          preAssessmentPercent: '',
          postAssessmentPercent: '',
          reAssessmentScore: '',
          topicImprovement: ''
        }
        category.topicScore.push(obj);
      })

        this.scoreCardDetails.scoreCard.forEach(score => {
          if(score.category == category._id){
            category.avgScore = +score.avgScore;
            category.avgTotalScore = +score.avgTotalScore;
            if(category.avgScore != ''){
              overallScore+=category.avgScore;
              overallTotalScore+=category.avgTotalScore;
              count++;
            }
            category.topicScore.forEach(topic => {
              if(score.assessmentSubType === 'Pre_Assessment'){
                this.setTopicDataForPreAssessment(score, topic);
              }else if(score.assessmentSubType === 'Post_Assessment'){
                this.setTopicDataForPostAssessment(score, topic);
              } else if(score.assessmentSubType === 'Re_Assessment'){
                this.setTopicDataForReAssessment(score, topic);
              }
          })
          }
      })
    }
    this.overallPercentage = (overallScore/overallTotalScore) * 100;
    this.setClassification(this.overallPercentage);
  }

  setTopicDataForPreAssessment(score, topic){
          score.topicDetails.forEach(t => {
            if(t.assessmentTopic == topic.topicName){
              topic.preAssessmentScore = t.score;
              topic.preAssessmentPercent = t.percentage;
              topic.postAssessmentScore = '';
              topic.postAssessmentPercent ='';
              topic.reAssessmentScore =''
              topic.topicImprovement = Math.abs((+topic.postAssessmentPercent) - (+topic.preAssessmentPercent));
            }
          })
  }

  setTopicDataForPostAssessment(score, topic){
          score.topicDetails.forEach(t => {
            if(t.assessmentTopic == topic.topicName){
              topic.postAssessmentScore = t.score;
              topic.postAssessmentPercent = t.percentage;
              topic.preAssessmentScore = '';
              topic.preAssessmentPercent ='';
              topic.reAssessmentScore ='';
              topic.topicImprovement = Math.abs((+topic.postAssessmentPercent) - (+topic.preAssessmentPercent));
            }
          })
  }

  setTopicDataForReAssessment(score, topic){
          score.topicDetails.forEach(t => {
            if(t.assessmentTopic == topic.topicName){
              topic.reAssessmentScore = t.score;
              topic.postAssessmentScore = '';
              topic.postAssessmentPercent ='';
              topic.preAssessmentScore = '';
              topic.preAssessmentPercent = '';
              topic.topicImprovement = Math.abs((+topic.postAssessmentPercent) - (+topic.preAssessmentPercent));
            }
          })
  }

  setClassification(overallPercentage){
    if(overallPercentage >= 90){
      this.classification = 'Exceptional';
    }else if(overallPercentage >=  80 && overallPercentage < 90){
      this.classification = 'Good';
    }else if(overallPercentage >= 70 && overallPercentage < 80){
      this.classification = 'Average';
    }else if(overallPercentage < 70){
      this.classification = 'Below Average';
    }
  }

  downloadScoreCard() {
    this.loader.open();
    let browserName = getBrowserName();
    var data = document.getElementById('parentdiv');
    html2canvas(data).then(canvas => {  
    
      const contentDataURL = canvas.toDataURL('image/jpeg')    
      let pdf = new jsPDF('p', 'mm', 'a4'); // A4 size page of PDF  
      var width = pdf.internal.pageSize.getWidth();
      var height = pdf.internal.pageSize.getHeight();
     
      let widthRatio = width / canvas.width;
      let heightRatio = height / canvas.height;
     
      let ratio = widthRatio > heightRatio ? heightRatio : widthRatio;
      //for chrome and other browsers
      if(browserName == 'ie'){
        // for IE
        pdf.addImage(contentDataURL, "JPEG", 0, -24, canvas.width * ratio, canvas.height * ratio,);
      }else{
        pdf.addImage(contentDataURL, "JPEG", 0, 0, canvas.width * ratio, canvas.height * ratio);
      }
      pdf.save(this.user.userId +'_Score Card.pdf'); // Generated PDF
      this.loader.close();
    });
  }

}
