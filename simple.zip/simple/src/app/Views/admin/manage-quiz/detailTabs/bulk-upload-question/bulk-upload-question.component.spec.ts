import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkUploadQuestionComponent } from './bulk-upload-question.component';

describe('BulkUploadQuestionComponent', () => {
  let component: BulkUploadQuestionComponent;
  let fixture: ComponentFixture<BulkUploadQuestionComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkUploadQuestionComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkUploadQuestionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
