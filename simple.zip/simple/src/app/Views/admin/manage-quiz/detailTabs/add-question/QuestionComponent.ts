import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormBuilder, FormControl, Validators, FormArray } from '@angular/forms';
import { AdminService } from '../../../admin.service';
import { MatSnackBar, MatCheckbox } from "@angular/material";
import { appSessionErr, appGenericErr, appVariables, resetLocalStorage, snackBarDuration } from '../../../../../app.constants';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';

@Component({
  selector: 'add-question',
  templateUrl: './question.html',
  styleUrls: ['./question.scss']
})
export class QuestionComponent implements OnInit {

  @ViewChild('selectAllCheckBox', { static: false }) private selectAllCheckBox: MatCheckbox;
  @ViewChild('imageFile', { static: false }) imageFile: ElementRef;

    public singleFlag:boolean = true;
    public multipleFlag:boolean = false;
    public matchFlag:boolean = false;
    public descriptiveFlag:boolean = false;
    public imageFlag:boolean = false;
    public singleCorrectAnswerQuestionForm:FormGroup;
    public multipleCrrectAnsQustForm: FormGroup;
    public matchColumnForm: FormGroup;
    public descriptiveQuestionForm: FormGroup;
    public imageQuestionForm: FormGroup;
    public questionBankId;
    public questionBankname;
    public questionType = 'Mcq';
    public correctOptArray = [];
    public subLob;
    public questionCategoryList = [];
    public categoryConfig;
    public duplicateErr = '';
    public imageForUI:any;
    public rawImage:any;

  constructor(
    private router: Router, 
    private fb: FormBuilder,
    private route: ActivatedRoute,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private loader: AppLoaderService
    ) {
      this.categoryConfig = {
        displayKey:"categoryName",
        search:true,
        height: '200px',
        placeholder:'Select',
        customComparator: ()=>{},
        limitTo: this.questionCategoryList.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder:'Search',
        searchOnKey: 'categoryName'
      }
     }

  ngOnInit() {
    this.questionBankId = this.route.snapshot.paramMap.get('id');
    this.questionBankname = this.route.snapshot.paramMap.get('name');
    this.subLob = JSON.parse(this.route.snapshot.paramMap.get('subLob'));
    if(this.questionBankId == null && this.questionBankname == null && this.subLob == null){
      this.snackBar.open('Please select Question Bank Name before adding questions.', 'OK', {duration: snackBarDuration});
      this.router.navigate(['/admin/manage-quiz']);
    }
    this.getAllCategory();
     this.createSingleAnswerQuestionForm();
     this.createMultipleAnswerQuestionForm();
     this.createMatchColumnQuestionForm();
     this.createDescAnswerQuestionForm();
     this.createImageQuestionForm();

  }

  getAllCategory(){
    this.loader.open();
    this.adminService.getAllCategory()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.questionCategoryList = res;
        this.categoryConfig.limitTo = this.questionCategoryList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('No Category Found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  
  createSingleAnswerQuestionForm(){
    this.singleCorrectAnswerQuestionForm = this.fb.group({
      correctOption: new FormControl('', Validators.required),
      question: new FormControl('', Validators.required),
      category: new FormControl([], Validators.required),
      option1: new FormControl(null, Validators.required),
      feedback1: new FormControl(''),
      option2: new FormControl(null, Validators.required),
      feedback2: new FormControl(''),
      option3: new FormControl(),
      feedback3: new FormControl(''),
      option4: new FormControl(),
      feedback4: new FormControl(''),
    })
  }

  createMultipleAnswerQuestionForm(){
    this.multipleCrrectAnsQustForm = this.fb.group({
      correctOption: new FormControl('', Validators.required),
      question: new FormControl('', Validators.required),
      category: new FormControl([], Validators.required),
      option1: new FormControl('', Validators.required),
      feedback1: new FormControl(''),
      option2: new FormControl('', Validators.required),
      feedback2: new FormControl(''),
      option3: new FormControl(''),
      feedback3: new FormControl(''),
      option4: new FormControl(''),
      feedback4: new FormControl(''),
      checkOpt1: new FormControl(false),
      checkOpt2: new FormControl(false),
      checkOpt3: new FormControl(false),
      checkOpt4: new FormControl(false)
    });
  }

  createMatchColumnQuestionForm(){
    this.matchColumnForm = this.fb.group({
      question: new FormControl('', Validators.required),
      category: new FormControl([], Validators.required),
      otherOptions: this.fb.array([]),
      colAOpt1: new FormControl(''),
      colAOpt2: new FormControl(''),
      colAOpt3: new FormControl(''),
      colAOpt4: new FormControl(''),
      colBOpt1: new FormControl('', Validators.required),
      colBOpt2: new FormControl('', Validators.required),
      colBOpt3: new FormControl('', Validators.required),
      colBOpt4: new FormControl('', Validators.required)
    })
  }

  createDescAnswerQuestionForm(){
    this.descriptiveQuestionForm = this.fb.group({
      question: new FormControl('', Validators.required),
      category: new FormControl([], Validators.required)
    })
  }

  createImageQuestionForm(){
    this.imageQuestionForm = this.fb.group({
      correctOption: new FormControl('', Validators.required),
      question: new FormControl('', Validators.required),
      category: new FormControl([], Validators.required),
      image: new FormControl('', Validators.required),
      option1: new FormControl(null,Validators.required),
      feedback1: new FormControl(''),
      option2: new FormControl(null,Validators.required),
      feedback2: new FormControl(''),
      option3: new FormControl(),
      feedback3: new FormControl(''),
      option4: new FormControl(),
      feedback4: new FormControl('')
    })
  }

  addOptionsFormGroup(): FormGroup {  
    return this.fb.group({
      optionName: [''],
      answer: ['', Validators.required],
    });  
  } 

  selectAll(e){
    if(e.checked == true){
      if(this.multipleCrrectAnsQustForm.get('option1').value != ''){
        this.multipleCrrectAnsQustForm.get('checkOpt1').setValue(true);
        this.correctOptArray.push(this.multipleCrrectAnsQustForm.get('option1').value);
      }
      if(this.multipleCrrectAnsQustForm.get('option2').value != ''){
        this.multipleCrrectAnsQustForm.get('checkOpt2').setValue(true);
        this.correctOptArray.push(this.multipleCrrectAnsQustForm.get('option2').value);
      }
      if(this.multipleCrrectAnsQustForm.get('option3').value != ''){
        this.multipleCrrectAnsQustForm.get('checkOpt3').setValue(true);
        this.correctOptArray.push(this.multipleCrrectAnsQustForm.get('option3').value);
      }
      if(this.multipleCrrectAnsQustForm.get('option4').value != ''){
        this.multipleCrrectAnsQustForm.get('checkOpt4').setValue(true);
        this.correctOptArray.push(this.multipleCrrectAnsQustForm.get('option4').value)
      }
      this.multipleCrrectAnsQustForm.get('correctOption').setValue(this.correctOptArray);
      
      this.correctOptArray =  [...new Set(this.correctOptArray)];
    } else {
      this.multipleCrrectAnsQustForm.get('checkOpt1').setValue(false);
      this.multipleCrrectAnsQustForm.get('checkOpt2').setValue(false);
      this.multipleCrrectAnsQustForm.get('checkOpt3').setValue(false);
      this.multipleCrrectAnsQustForm.get('checkOpt4').setValue(false);
      this.correctOptArray = [];
      this.multipleCrrectAnsQustForm.get('correctOption').setValue('');
    }
  }

  checkDistinctValue(form){
    let count = 0;
    let optionArr = [form.option1, form.option2, form.option3, form.option4];
    for(let i = 0; i < optionArr.length; i++){
      for(let j=i+1; j< optionArr.length; j++){
        if(optionArr[i] == optionArr[j]){
          count++;
        }
      }
    }
    if(count > 0){
      this.duplicateErr = 'Options should be Distinct. Please add distinct options and save again.';
      return false;
    }else{
      this.duplicateErr = '';
      return true;
    }
  }

  checkBoxSelected(value, event){
    if(event.checked == true){
      this.correctOptArray.push(value);
      this.multipleCrrectAnsQustForm.get('correctOption').setValue(this.correctOptArray);
    }else{
      this.correctOptArray = this.correctOptArray.filter(v => v != value);
      this.multipleCrrectAnsQustForm.get('correctOption').setValue(this.correctOptArray);
    }
  }

  addMatchOption(){
    (<FormArray>this.matchColumnForm.get('otherOptions')).push(this.addOptionsFormGroup());
  }

  deleteMatchOption(deleteId){
    (<FormArray>this.matchColumnForm.get('otherOptions')).removeAt(deleteId);
  }

  submitQuestion(){
    let data = {
      questionBankId: +this.questionBankId,
      questionBankName: this.questionBankname,
      status: 'Active',
      subLob: this.subLob,
      questionList: [{
        questionId: '',
        category: '',
        type: this.questionType,
        questionText: '',
        choiceNumber: '4',
        correctAnswer: [],
        selectedAnswer: [],
        status: 'Active',
        optionList: [],
        discriptiveAnswer: '',
        imagePath: '',
        imageByte: null,
        imageForUI: ''
      }]
    }
    for( let i=0; i<4 ; i++){
      let obj = {
        optionId:'',
        optionName:'',
        answer:'',
        feedback:''
      }
      data.questionList[0].optionList.push(obj);
    }
      if(this.singleFlag == true){
        if(this.checkDistinctValue(this.singleCorrectAnswerQuestionForm.value)){
          this.singleCorrectAnsQuestionObj(this.singleCorrectAnswerQuestionForm.value, data);
        }
      }
      else if(this.multipleFlag == true){
        if(this.checkDistinctValue(this.multipleCrrectAnsQustForm.value)){
          this.multipleCorrectAnsQuestionObj(this.multipleCrrectAnsQustForm.value,data);
        }
        // this.multipleCorrectAnsQuestionObj(this.multipleCrrectAnsQustForm.value,data);
      }
      else if(this.matchFlag == true){
        this.MatchQuestionObj(this.matchColumnForm.value, data);
      }
      else if(this.descriptiveFlag == true){
        this.descQuestionObj(this.descriptiveQuestionForm.value, data);
      }
      else if(this.imageFlag == true){
        
       var imageStr = this.rawImage;
        var base64result = imageStr.split(',')[1];
        this.imageForUI = base64result;
        this.imageQuestionForm.get('image').setValue(this.imageForUI);
        if(this.checkDistinctValue(this.imageQuestionForm.value)){
          this.imageQuestionObj(this.imageQuestionForm.value, data);
        }
      }
  }

  MatchQuestionObj(questionData, postData){
    for(let index = 0 ; index < postData.questionList.length; index ++){
      postData.questionList[index].questionText =  questionData.question;
      postData.questionList[index].category = questionData.category.categoryName;
      for (let i = 1; i <=4 ; i++){
        let colAOpt = 'colAOpt' + i;
        let colBOpt = 'colBOpt' + i;
        postData.questionList[index].optionList[i-1].optionName = questionData[colAOpt];
        postData.questionList[index].optionList[i-1].answer = questionData[colBOpt];
      }
      if(questionData.otherOptions.length > 0){
        questionData.otherOptions.forEach(opt => {
          let optionObj = {
            optionId:'',
            optionName:opt.optionName,
            answer:opt.answer,
            feedback: ''
          }
          postData.questionList[index].optionList.push(optionObj);
        })
      }
    }
    this.sendQuestionData(postData);
  }

  descQuestionObj(questionData, postData){
    for(let index = 0 ; index < postData.questionList.length; index ++){
      postData.questionList[index].questionText =  questionData.question;
      postData.questionList[index].category = questionData.category.categoryName;
    }
    this.sendQuestionData(postData);
  }

  imageQuestionObj(questionData, postData){
    let correctFeedback = '';
    for(let index = 0 ; index < postData.questionList.length; index ++){
      postData.questionList[index].questionText =  questionData.question;
      postData.questionList[index].category = questionData.category.categoryName;
      let ansOnj = {
        optionId: '',
        optionName: questionData.correctOption,
        answer:'',
        feedback: ''
      }
      
      postData.questionList[index].imageForUI = questionData.image;
      for (let i = 1; i <=4 ; i++){
        let option = 'option' + i;
        let feedback = 'feedback' + i;
        if(questionData.correctOption == questionData[option]){
          correctFeedback = questionData[feedback];
        }
        ansOnj.feedback = correctFeedback;
        postData.questionList[index].optionList[i-1].optionName = questionData[option];
        postData.questionList[index].optionList[i-1].feedback = questionData[feedback];
      }
      postData.questionList[index].correctAnswer.push(ansOnj);
    }
    this.sendQuestionData(postData);
  }

  singleCorrectAnsQuestionObj(questionData, postData){
    let correctFeedback = '';
    for(let index = 0 ; index < postData.questionList.length; index ++){
      postData.questionList[index].questionText =  questionData.question;
      postData.questionList[index].category = questionData.category.categoryName;
      let ansOnj = {
        optionId: '',
        optionName: questionData.correctOption,
        answer:'',
        feedback: ''
      }
      for (let i = 1; i <=4 ; i++){
        let option = 'option' + i;
        let feedback = 'feedback' + i;
        if(questionData.correctOption == questionData[option]){
          correctFeedback = questionData[feedback];
        }
        ansOnj.feedback = correctFeedback;
        postData.questionList[index].optionList[i-1].optionName = questionData[option];
        postData.questionList[index].optionList[i-1].feedback = questionData[feedback];
      }
      postData.questionList[index].correctAnswer.push(ansOnj);
    }
    this.sendQuestionData(postData);
  }

  multipleCorrectAnsQuestionObj(questionData, postData){
    for(let index = 0 ; index < postData.questionList.length; index ++){
      postData.questionList[index].questionText =  questionData.question;
      postData.questionList[index].category = questionData.category.categoryName;
      if(this.correctOptArray.length >= 1){
        this.correctOptArray.forEach(opt => {
          let obj = {
            optionId:'',
            optionName:opt,
            answer:'',
            feedback:''
          }
          postData.questionList[index].correctAnswer.push(obj);
        })
      }
      for (let i = 1; i <=4 ; i++){
        let option = 'option' + i;
        let feedback = 'feedback' + i;
        postData.questionList[index].optionList[i-1].optionName = questionData[option];
        postData.questionList[index].optionList[i-1].feedback = questionData[feedback];
      }
    }
    postData.questionList[0].correctAnswer.forEach(option => {
      for(let opt of postData.questionList[0].optionList){
        if(option.optionName == opt.optionName){
          option.feedback = opt.feedback;
          break;
        }
      }
    })

   
    this.sendQuestionData(postData);
  }

  sendQuestionData(data){
    this.loader.open();
    this.adminService.addQuestion(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else {
        this.snackBar.open('Question added successfuly', 'OK', {duration: snackBarDuration});
        this.resetQuestionForms();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else{
      this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
    }
    })
  }

  imageFileSelect(event){
    if (event.target.files.length > 0) {
      const file = event.target.files[0];
      
      const reader = new FileReader();
      reader.readAsDataURL(file);
      //reader.readAsBinaryString(file);
      reader.onload = () => {
        this.rawImage = reader.result;
          this.imageQuestionForm.get('image').setValue(reader.result);
      };
    }else{
      this.imageQuestionForm.get('image').setValue('');
    }
  }

  resetQuestionForms(){
    this.createSingleAnswerQuestionForm();
    this.createMultipleAnswerQuestionForm();
    if(this.selectAllCheckBox){
      this.selectAllCheckBox.checked = false;
    }
    if(this.imageFile){
      this.imageFile.nativeElement.value = null;
    }
    this.createMatchColumnQuestionForm();
    this.createImageQuestionForm();
    this.createDescAnswerQuestionForm();
  }
}
