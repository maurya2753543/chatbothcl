import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../admin.service';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables } from '../../../../../app.constants';

@Component({
  selector: 'app-manage-category',
  templateUrl: './manage-category.component.html',
  styleUrls: ['./manage-category.component.scss']
})
export class ManageCategoryComponent implements OnInit {

  public categoryName = '';
  public patternErr = '';

  constructor(
    private adminService: AdminService,
    private loader: AppLoaderService,
    private snackBar: MatSnackBar,
    private router: Router
  ) { }

  ngOnInit() {
  }

  patternValidate(categoryName){
    if(categoryName.match('^[a-zA-Z]+[_a-zA-Z]*$')){
      this.patternErr = '';
    }else{
      this.patternErr = 'Only Alphabets and Underscores are allowed';
    }
  }

  saveCategory(){
    this.loader.open();
    let categoryObj = {
      categoryName: this.categoryName,
      hasTopic: false
    }
    this.adminService.saveCategory(categoryObj)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else{
        this.snackBar.open('Category Saved Successfully', 'OK', {duration: snackBarDuration});
        this.categoryName = '';
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }        
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

}