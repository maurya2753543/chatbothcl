import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateQuestionBankComponent } from './update-question-bank.component';

describe('UpdateQuestionBankComponent', () => {
  let component: UpdateQuestionBankComponent;
  let fixture: ComponentFixture<UpdateQuestionBankComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UpdateQuestionBankComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UpdateQuestionBankComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
