import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from "@angular/material";
import { appSessionErr, appGenericErr, appVariables, resetLocalStorage, snackBarDuration } from '../../../../../app.constants';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';

@Component({
  selector: 'app-add-question',
  templateUrl: './add-question.component.html',
  styleUrls: ['./add-question.component.scss']
})
export class AddQuestionComponent implements OnInit {
  
  public questionBankList = [];
  public questionBankId = '';
  public questionBankSelected;
  public config;
  public lobList = [];
  public lobConfig;
  public subLobList = [];
  public subLobConfig;
  public lob;
  public subLob;

  constructor(
    private router: Router,
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private loader: AppLoaderService
    ) {
      this.config = {
        displayKey:"questionBankName", //if objects array passed which key to be displayed defaults to description
        search:true,//true/false for the search functionlity defaults to false,
        height: '200px', //height of the list so that if there are more no of items it can show a scroll defaults to auto. With auto height scroll will never appear
        placeholder:'Select', // text to be displayed when no item is selected defaults to Select,
        customComparator: ()=>{}, // a custom function using which user wants to sort the items. default is undefined and Array.sort() will be used in that case,
        limitTo: this.questionBankList.length, // a number thats limits the no of options displayed in the UI similar to angular's limitTo pipe
        moreText: 'more', // text to be displayed whenmore than one items are selected like Option 1 + 5 more
        noResultsFound: 'No results found! (Please make sure Sub-LOB is selected)', // text to be displayed when no items are found while searching
        searchPlaceholder:'Search', // label thats displayed in search input,
        searchOnKey: 'questionBankName' // key on which search should be performed this will be selective search. if undefined this will be extensive search on all keys
        }
        this.lobConfig = {
          displayKey:"lobName",
          search:true,
          height: '200px',
          placeholder:'Select',
          customComparator: ()=>{},
          limitTo: this.lobList.length,
          moreText: 'more',
          noResultsFound: 'No results found!',
          searchPlaceholder:'Search',
          searchOnKey: 'lobName'
        }
        this.subLobConfig = {
          displayKey:"subLobName",
          search:true,
          height: '200px',
          placeholder:'Select',
          customComparator: ()=>{},
          limitTo: this.subLobList.length,
          moreText: 'more',
          noResultsFound: 'No results found!(Please make sure LOB is selected)',
          searchPlaceholder:'Search',
          searchOnKey: 'subLobName'
        }
     }

  ngOnInit() {
    //this.getQuesionBank();
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.loader.close();
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        this.loader.close();
        this.lobList = res;
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getSubLob(){
    this.loader.open();
    this.subLob = [];
    this.subLobList = [];
    this.questionBankSelected = [];
    this.questionBankList = [];
    if(this.lob){
      this.adminService.getSubLob(this.lob.lobName)
      .subscribe(res => {
        if(res == 'ERROR'){
          this.loader.close();
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.loader.close();
          this.snackBar.open('Sub LOB not found for selected LOB', 'OK', {duration: snackBarDuration});
        }else{
          this.loader.close();
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
    
  }

  getQuestionBank(){
    this.loader.open();
    this.questionBankSelected = [];
    this.questionBankList = [];
    if(this.subLob){
      this.adminService.getQuestionBank(this.subLob.subLobId)
      .subscribe(res => {
        if(res == 'ERROR'){
          this.loader.close();
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.loader.close();
          this.snackBar.open('Question Banks not found for selected Sub-LOB', 'OK', {duration: snackBarDuration});
        }else{
          this.loader.close();
          this.questionBankList = res;
          this.config.limitTo = this.questionBankList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }
    
  }

  addQuestionNavigate(){
    // let questionBankName = '';
    // if(this.questionBankId!= '')
    // this.questionBankList.forEach(qb => {
    //   if(qb.questionBankId == this.questionBankId){
    //     questionBankName = qb.questionBankName
    //   }
    // });
    if(this.questionBankSelected != ''){
      this.router.navigate(['/admin/add-question', {id: this.questionBankSelected.questionBankId, name:this.questionBankSelected.questionBankName, subLob:JSON.stringify(this.subLob), si: true}]);
    }
      //this.router.navigate(['/admin/add-question', {id: this.questionBankId, name:questionBankName, si: true}]);    
  }
}


