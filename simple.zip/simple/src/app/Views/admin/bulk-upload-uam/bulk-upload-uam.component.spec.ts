import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BulkUploadUamComponent } from './bulk-upload-uam.component';

describe('BulkUploadUamComponent', () => {
  let component: BulkUploadUamComponent;
  let fixture: ComponentFixture<BulkUploadUamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BulkUploadUamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BulkUploadUamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
