import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, FormControl } from '@angular/forms';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables, appWeeks } from '../../../../../app.constants';
import * as cloneDeep from 'lodash/cloneDeep';

@Component({
  selector: 'app-create-training-plan',
  templateUrl: './create-training-plan.component.html',
  styleUrls: ['../training-component.scss']
})
export class CreateTrainingPlanComponent implements OnInit {

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private loader: AppLoaderService,
    private router: Router
  ) {
    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.lobConfig = {
      ... configObj,
      displayKey:"lobName",
      placeholder:'Select LOB',
      limitTo: this.lobList.length,
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      ...configObj,
      displayKey:"subLobName",
      placeholder:'Select Sub LOB',
      limitTo: this.subLobList.length,
      searchOnKey: 'subLobName'
    }
    this.weekConfig = {
      ...configObj,
      displayKey: 'name',
      placeholder: 'Select Week',
      limitTo: this.weekList.length,
      searchOnKey: 'name'
    }
   }

  public trainingPlanForm: FormGroup;
  public lobList = [];
  public subLobList = [];
  public lobConfig;
  public subLobConfig;
  public weekList = appWeeks;
  public weekConfig;
  public showWeekDetails = false;

  ngOnInit() {
    this.createTraingPlanForm();
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  getSubLob(lob){
    this.loader.open();
    this.trainingPlanForm.get('subLob').setValue([]);
    this.subLobList = [];
    if(lob){
      this.adminService.getSubLob(this.trainingPlanForm.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }    
  }

  createTraingPlanForm(){
    this.trainingPlanForm = this.fb.group({
      trainingPlanName: ['', Validators.required],
      lob: [[],Validators.required],
      subLob: [[], Validators.required],
      weekList: this.fb.array([]),
      weekSelected: [[], Validators.required]
    })
  }

  addWeeks() {
    let weekName = '';
    let count = 0
    this.showWeekDetails = true;
    if(this.trainingPlanForm.get('weekSelected').value){
      weekName = this.trainingPlanForm.get('weekSelected').value.code;
    }else{
      this.showWeekDetails = false;
      count ++;
    }
    if(this.trainingPlanForm.get('weekList').value.length > 0){
      this.trainingPlanForm.get('weekList').value.forEach(week => {
        if(week.weekName == weekName){
          count++
          //return;
        }
      })
    }
    const control =  new FormGroup({
      weekName: new FormControl(weekName?weekName:'', Validators.required),
      weekTitle: new FormControl('', Validators.required),
      taskList: new FormControl([{taskId: '', taskName: ''}])
    });
    if(count == 0){
      (<FormArray>this.trainingPlanForm.get('weekList')).push(control);
    }
    // if(this.trainingPlanForm.get('weekSelected').value == undefined){
    //   this.showWeekDetails = false;
    // }
  }

  deleteWeek(weekIndex){
    (<FormArray>this.trainingPlanForm.get('weekList')).removeAt(weekIndex);
  }

  addTask(weekIndex?:any){
    this.trainingPlanForm.get('weekList').value[weekIndex].taskList.push({taskId:'',taskName:''});
  }

  deleteTask(taskIndex:number, weekIndex){
    this.trainingPlanForm.get('weekList').value[weekIndex].taskList.splice(taskIndex,1);
  }

  taskChange(TaskPosition: any, value: any, weekIndex:any){
    if(this.trainingPlanForm.get('weekList').value[weekIndex]){
      this.trainingPlanForm.get('weekList').value[weekIndex].taskList[TaskPosition].taskName = value;
    }
    
  }

  createTrainingPlanPostData(){
    if(this.validateTaskList()){
      let data = {
        trainingPlanId : '',
        trainingPlanName: this.trainingPlanForm.get('trainingPlanName').value,
        subLob: this.trainingPlanForm.get('subLob').value,
        trainingPlanWeek: this.trainingPlanForm.get('weekList').value,
        trainingPlanStatus: ''
      }
      this.saveTrainingPlan(data);
    }else{
      this.snackBar.open('Empty tasks names are not allowed. Please check Week schedules before saving plan.', 'OK', {duration: snackBarDuration});
      return;
    }
  }

  validateTaskList(){
    let count = 0;
    this.trainingPlanForm.get('weekList').value.forEach(week => {
        week.taskList.forEach(task => {
          if(task.taskName == ''){
            count++;
          }
        })
      })
      if(count > 0){
        return false;
      }else{
        return true;
      }
  }
   
  private saveTrainingPlan(data){
    this.loader.open();
      this.adminService.createTrainingPlan(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Training Plan added successfully', 'OK', {duration: snackBarDuration});
        this.resetData();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  resetData(){
    this.trainingPlanForm.reset();
    this.createTraingPlanForm();
    this.showWeekDetails = false;
  }
}
