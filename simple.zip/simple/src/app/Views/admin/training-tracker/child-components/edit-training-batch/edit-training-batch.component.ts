import { Component, OnInit, ChangeDetectorRef, Inject, AfterContentChecked } from '@angular/core';
import { AdminService } from '../../../admin.service';
import { MatSnackBar, MatDialog, MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormBuilder, Validators, FormGroup } from '@angular/forms';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { snackBarDuration, appGenericErr, appVariables, resetLocalStorage, appSessionErr, appTrainingBatchStatus, digitPattern } from '../../../../../app.constants';
import { DatePipe } from '@angular/common';
import { DialogData } from '../../../../quiz/question-set/question-set.component';
import * as cloneDeep from 'lodash/cloneDeep';
import * as moment from 'moment';

@Component({
  selector: 'app-edit-training-batch',
  templateUrl: './edit-training-batch.component.html',
  styleUrls: ['../training-component.scss']
})
export class EditTrainingBatchComponent implements OnInit {

  public startDate;
  public endDate;
  public trainingBatchList = [];
  public showPreviewFlag = false;
  public currentPage = 1;
  public itemsPerPage = 6;

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private loader: AppLoaderService,
    private router: Router,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
  }
  
  getTrainingBatchList(){
    this.loader.open();
    let startDate = new DatePipe('en-US').transform(this.startDate, 'yyyy-MMM-dd');
    let endDate = new DatePipe('en-US').transform(this.endDate, 'yyyy-MMM-dd');
    this.adminService.getTrainingBatch(startDate, endDate)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.trainingBatchList = res;
          this.trainingBatchList.forEach(batch => {
            batch['status'] = cloneDeep(batch.trainingBatchStatus);
            batch.status = batch.status.replace(/_/g, ' ');
          })
          this.showPreviewFlag = true;
        }
      }
    }, err => {
      this.loader.close();
      this.showPreviewFlag = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  openDialog(data): void {
    const dialogRef = this.dialog.open(EditTrainingBatchDialog, {
      width: '8000px',
      height: '600px',
      data: data
    });

    dialogRef.afterClosed().subscribe(result => {
      this.getTrainingBatchList();
    });  
  }

}

@Component({
  selector: 'app-edit-training-batch-dialog',
  templateUrl: './edit-training-batch-dialog.html',
  styleUrls: ['../training-component.scss']
})
export class EditTrainingBatchDialog implements OnInit, AfterContentChecked {

  public editTrainingBatchForm: FormGroup;
  public trainingBatchData;
  public trainingPlanConfig;
  public trainingPlanList = [];
  public trainingBatchStatus = appTrainingBatchStatus;

  constructor(
    public dialogRef: MatDialogRef<EditTrainingBatchDialog>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private loader: AppLoaderService,
    private snackBar: MatSnackBar,
    private adminService: AdminService,
    private router: Router,
    private fb: FormBuilder,
    private cdRef : ChangeDetectorRef
  ){
    this.trainingBatchData = data;
    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.trainingPlanConfig = {
      ...configObj,
      displayKey:"trainingPlanName",
      placeholder:'Select Training Plan',
      limitTo: this.trainingPlanList.length,
      searchOnKey: 'trainingPlanName'
    }
  }

  ngOnInit(){
    this.getTrainingPlan(this.trainingBatchData.subLob.subLobId);
    this.createTrainingBatchForm(this.trainingBatchData);
  }

  ngAfterContentChecked() : void {
    this.cdRef.detectChanges();
  }

  changeDateFormat(inputDate){  // expects Y-m-d
    var splitDate = inputDate.split('-');
    if(splitDate.count == 0){
        return null;
    }

    var year = splitDate[0];
    var month = splitDate[1];
    var day = splitDate[2]; 

    return month + '\\' + day + '\\' + year;
}


  createTrainingBatchForm(data?: any){
    let disableTrainingPlan = false;
    let batchTrainers = '';
    let traineeList = '';
    let wrongTraineeList = '';
    let startDate = data.trainingBatchStartDate.replace(/-/g,' ');
    let endDate = data.trainingBatchEndDate.replace(/-/g,' ');
    if(data){
      batchTrainers = data.batchTrainers.join(', ');
      traineeList = data.traineeList.join(', ');
      wrongTraineeList = data.wrongTraineesList.join(', ');
      if(data.trainingBatchStatus != 'Not_Started_Yet'){
        disableTrainingPlan = true;
      }
    }
    this.editTrainingBatchForm = this.fb.group({
      trainingBatchName: [data.trainingBatchName || ''],
      lob: [data.subLob.lob.lobName || ''],
      subLob: [data.subLob.subLobName || ''],
      startDate: [new Date(startDate) || ''],
      noOfDays: [data.numberOfDays || '', [Validators.required, Validators.pattern(digitPattern)]],
      endDate: [new Date(endDate) || ''],
      batchTrainer: [batchTrainers || ''],
      traineeList: [traineeList || ''],
      wrongTraineeList: [wrongTraineeList || ''],
      status: [data.trainingBatchStatus || '', Validators.required],
      trainingPlan: [{value: data.trainingPlan || [], disabled: disableTrainingPlan}, Validators.required],
      includeWeekends: [data.weekendIncluded || false]
    })
  }

  setEndDate(){
    let days = this.editTrainingBatchForm.get('noOfDays').value;
    let startDate = cloneDeep(this.editTrainingBatchForm.get('startDate').value);
    //let endDate = new Date().setDate(startDate.getDate()+ parseInt(days));
    let endDate = null;
    let count = 0;
    if(this.editTrainingBatchForm.get('includeWeekends').value == false){
      while(count < days){
        endDate = new Date(startDate.setDate(startDate.getDate() + 1));
        if(endDate.getDay() != 0 && endDate.getDay() != 6){
           count++;
        }
      }
    }else{
      endDate = new Date().setDate(startDate.getDate()+ parseInt(days));
    }
    
    this.editTrainingBatchForm.get('endDate').setValue(new Date(endDate));
  }

  getTrainingPlan(subLobId){
    this.loader.open();
    //this.editTrainingBatchForm.get('trainingPlan').setValue([]);
    this.trainingPlanList = [];
      this.adminService.getTrainingPlan(subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }else{
          if(res.length> 0){
            this.trainingPlanList = res;
          }
          this.trainingPlanConfig.limitTo = this.trainingPlanList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
  }

  createTrainingBatchData(){
    let data = {
      trainingBatchId: this.trainingBatchData.trainingBatchId,
      trainingBatchName: this.trainingBatchData.trainingBatchName,
      subLob: this.trainingBatchData.subLob,
      trainingBatchStartDate: this.trainingBatchData.trainingBatchStartDate,
      numberOfDays: this.editTrainingBatchForm.get('noOfDays').value,
      trainingBatchEndDate: new DatePipe('en-US').transform(this.editTrainingBatchForm.get('endDate').value, 'yyyy-MMM-dd'),
      batchTrainers: this.trainingBatchData.batchTrainers,
      traineeList: this.trainingBatchData.traineeList,
      trainingBatchStatus: this.editTrainingBatchForm.get('status').value,
      trainingPlan: this.editTrainingBatchForm.get('trainingPlan').value,
      isWeekendIncluded: this.editTrainingBatchForm.get('includeWeekends').value
    }
    this.editTrainingBatch(data);
  }

  private editTrainingBatch(data){
    this.loader.open();
      this.adminService.editTrainingBatch(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Training Batch saved successfully', 'OK', {duration: snackBarDuration});
        this.dialogRef.close();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
}
