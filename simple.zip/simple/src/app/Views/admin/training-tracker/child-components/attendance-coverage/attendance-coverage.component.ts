import { Component, OnInit, ViewChild, AfterContentChecked, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AdminService } from '../../../admin.service';
import { MatSnackBar, MatTabGroup } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables } from '../../../../../app.constants';
import { DatePipe } from '@angular/common';
import * as cloneDeep from 'lodash/cloneDeep';
import * as moment from 'moment';

@Component({
  selector: 'app-attendance-coverage',
  templateUrl: './attendance-coverage.component.html',
  styleUrls: ['../training-component.scss']
})
export class AttendanceCoverageComponent implements OnInit, AfterContentChecked {

  @ViewChild('tabGroup', { static: false }) private tabGroup: MatTabGroup;

  public form: FormGroup;
  public lobList = [];
  public subLobList = [];
  public trainingBatchList = [];
  public lobConfig;
  public subLobConfig;
  public trainingBatchConfig;
  public showPreviewFlag = false;
  public currentDate: Date = new Date();
  //public attendanceForm: FormGroup;
  public traineeList = [];
  public trainingDate: Date;
  public minDate;
  public maxDate;
  public currentPage = 1;
  public itemsPerPage = 10;

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private loader: AppLoaderService,
    private router: Router,
    private changeDetector: ChangeDetectorRef
  ) {
    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.lobConfig = {
      ... configObj,
      displayKey:"lobName",
      placeholder:'Select LOB',
      limitTo: this.lobList.length,
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      ...configObj,
      displayKey:"subLobName",
      placeholder:'Select Sub LOB',
      limitTo: this.subLobList.length,
      searchOnKey: 'subLobName'
    }
    this.trainingBatchConfig = {
      ...configObj,
      displayKey:"trainingBatchName",
      placeholder:'Select Training Batch Name',
      limitTo: this.trainingBatchList.length,
      searchOnKey: 'trainingBatchName'
    }
   }

  ngOnInit() {
    this.createForm();
    this.getAllLob();
  }

  ngAfterContentChecked() : void {
    this.changeDetector.detectChanges();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  getSubLob(lob){
    this.loader.open();
    this.form.get('subLob').setValue([]);
    this.form.get('trainingBatch').setValue([]);
    this.trainingBatchList = [];
    this.subLobList = [];
    this.showPreviewFlag = false;
    if(lob){
      this.adminService.getSubLob(this.form.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }    
  }

  createForm(){
    this.form = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      lob: [[],Validators.required],
      subLob: [[], Validators.required],
      trainingBatch: [[], Validators.required]
    })
  }

  getTrainingBatchForAttendanceCoverage(){
    let startDate = new DatePipe('en-US').transform(this.form.get('startDate').value, 'yyyy-MMM-dd');
    let endDate = new DatePipe('en-US').transform(this.form.get('endDate').value, 'yyyy-MMM-dd');
    let subLobId = this.form.get('subLob').value != undefined ? this.form.get('subLob').value.subLobId: '';
    this.form.get('trainingBatch').setValue([]);
    this.trainingBatchList = [];
    if(startDate && endDate && subLobId!=''){
      this.loader.open();
      this.adminService.getTrainingBatchForAttendanceCoverage(startDate, endDate, subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
        }else{
          if(res.length> 0){
            this.trainingBatchList = res;
          }
          this.trainingBatchConfig.limitTo = this.trainingBatchList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }
  }

  // createAttendanceForm(){
  //   this.attendanceForm = this.fb.group({
  //     trainingDate: ['', Validators.required],
  //     traineeList: [this.form.get('trainingBatch').value.traineeDetail]
  //   })
  // }

  getTraineesAttendance(){
    this.loader.open();
    let trainingDate = new DatePipe('en-US').transform(this.trainingDate, 'yyyy-MMM-dd');
    let trainingBatchId = this.form.get('trainingBatch').value.trainingBatchId;
    this.adminService.getTraineesAttendance(trainingDate, trainingBatchId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Attendance records not found for selected training date.', 'OK', {duration: snackBarDuration});
        this.markAttendance(res);
      }else{
        if(res.length> 0){
          this.markAttendance(res);
        }
      }
    }, err => {
      this.loader.close();
      this.showPreviewFlag = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Attendance records not found for selected training date.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  markAttendance(res){
    if(res == null){
      this.traineeList.forEach(trainee => {
        trainee.isChecked = false;
      })
    }else if(res.length > 0){
        this.traineeList.forEach(trainee =>{
          trainee.isChecked = false
          if(res.indexOf(trainee.traineeId) > -1){
            trainee.isChecked = true;
          }
        })
    }
  }

  selectAll(event){
    if(event.checked){
      this.traineeList.forEach(trainee => {
        trainee.isChecked = true;
      })
    }else if(!event.isChecked){
      this.traineeList.forEach(trainee => {
        trainee.isChecked = false;
      })
    }
  }

  createTrainingAttendanceData(){
    let attendanceList = [];
    if(this.traineeList.length > 0){
      this.traineeList.forEach(trainee => {
        if(trainee.isChecked){
          attendanceList.push(trainee.traineeId)
        }
      })
    }
    let obj = {
      trainingBatchAttendanceId: '',
      trainingBatchId: this.form.get('trainingBatch').value.trainingBatchId,
      trainingBatchName: this.form.get('trainingBatch').value.trainingBatchName,
      subLob: this.form.get('subLob').value,
      trainingPlanId: this.form.get('trainingBatch').value.trainingPlan._id,
      trainingPlanName: this.form.get('trainingBatch').value.trainingPlan.trainingPlanName,
      traineeList: attendanceList,
      trainingDate: new DatePipe('en-US').transform(this.trainingDate, 'yyyy-MMM-dd')
    }
    this.saveTrainingBatchAttendance(obj);
  }

  saveTrainingBatchAttendance(data){
    this.loader.open();
      this.adminService.saveTrainingBatchAttendance(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Training Batch Attendance Saved Successfully', 'OK', {duration: snackBarDuration});
        // this.trainingDate = null;
        // this.traineeList = [];
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  reset(){
    this.form.reset();
    this.createForm();
    this.showPreviewFlag = false;
  }

  openTabs(){
    this.maxDate = moment(this.form.get('trainingBatch').value.trainingBatchEndDate).toDate();
    this.minDate = moment(this.form.get('trainingBatch').value.trainingBatchStartDate).toDate();
    this.traineeList = cloneDeep(this.form.get('trainingBatch').value.traineeDetail);
    if(this.traineeList.length > 0){
      this.traineeList.forEach(trainee => {
        trainee['isChecked'] = false;
      })
      this.showPreviewFlag = true;
    }else{
      this.snackBar.open('Trainee records not available for selected search criteria.', 'OK', {duration: snackBarDuration});
      this.showPreviewFlag = false;
      return;
    }
  }

}
