import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appVariables, appSessionErr, resetLocalStorage } from '../../../../../app.constants';
import * as XLSX from 'xlsx';
import * as cloneDeep from 'lodash/cloneDeep';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-batch-specific-report',
  templateUrl: './batch-specific-report.component.html',
  styleUrls: ['../training-component.scss']
})
export class BatchSpecificReportComponent implements OnInit {

  public form: FormGroup;
  public lobList = [];
  public subLobList = [];
  public trainingBatchList = [];
  public lobConfig;
  public subLobConfig;
  public trainingBatchConfig;
  public batchSpecificReport = [];
  public showReport = false;
  public currentPage = 1;
  public itemsPerPage = 6;
  public missingDataErr = '';
  public currentDate = new Date();

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private loader: AppLoaderService,
    private router: Router
  ) { 
    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.lobConfig = {
      ... configObj,
      displayKey:"lobName",
      placeholder:'Select LOB',
      limitTo: this.lobList.length,
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      ...configObj,
      displayKey:"subLobName",
      placeholder:'Select Sub LOB',
      limitTo: this.subLobList.length,
      searchOnKey: 'subLobName'
    }
    this.trainingBatchConfig = {
      ...configObj,
      displayKey:'trainingBatchName',
      placeholder:'Select Training Batch Name',
      limitTo: this.trainingBatchList.length,
      searchOnKey: 'trainingBatchName'
    }
  }

  ngOnInit() {
    this.createForm();
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  getSubLob(lob){
    this.loader.open();
    this.form.get('subLob').setValue([]);
    this.subLobList = [];
    this.form.get('trainingBatch').setValue([]);
    this.trainingBatchList = [];
    this.showReport = false;
    if(lob){
      this.adminService.getSubLob(this.form.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }    
  }

  getTrainingBatch(){
    this.loader.open();
    this.form.get('trainingBatch').setValue([]);
    this.trainingBatchList = [];
    this.showReport = false;
    if(this.form.get('startDate').value != '' && this.form.get('endDate').value != ''){
      this.missingDataErr = '';
    let startDate = new DatePipe('en-US').transform(this.form.get('startDate').value, 'yyyy-MMM-dd');
    let endDate = new DatePipe('en-US').transform(this.form.get('endDate').value, 'yyyy-MMM-dd');
    if(this.form.get('subLob').value){
    let subLobId = this.form.get('subLob').value.subLobId;
    this.adminService.getTrainingBatchForAttendanceCoverage(startDate, endDate, subLobId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.trainingBatchList = res;
        }
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.snackBar.open('Training Batch not found.', 'OK', {duration: snackBarDuration});
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }else{
    this.loader.close();
  }
  }else{
    this.loader.close();
    this.missingDataErr = 'Start date and End date is required';
    this.form.get('subLob').setValue([]);
    return;
    }
  }

  checkDate(){
    if(this.form.get('startDate').value != '' && this.form.get('endDate').value != ''){
      this.missingDataErr = '';
    }else{
      this.missingDataErr = 'Start date and End date is required';
    }
    this.getTrainingBatch();
    this.showReport = false;
  }

  createForm(){
    this.form = this.fb.group({
      startDate: ['', Validators.required],
      endDate: ['', Validators.required],
      lob: [[],Validators.required],
      subLob: [[], Validators.required],
      trainingBatch: [[], Validators.required]
    })
  }

  getBatchSpecificReport(){
    this.loader.open();
    this.batchSpecificReport = [];
    let trainingBatchId = this.form.get('trainingBatch').value.trainingBatchId;
    this.adminService.getBatchSpecificReport(trainingBatchId)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else if(res == null){
        this.snackBar.open('No Records found for selected search criteria.', 'OK', {duration: snackBarDuration});
        //this.showReport = true;
      }
      else if(res !== null && res != []){
        this.batchSpecificReport = res;
        this.showReport = true; 
      }
    }, err => {
      this.loader.close();
      this.showReport = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '404'){
        this.batchSpecificReport = [];
        this.snackBar.open('Batch Specific Report Not Found', 'OK', {duration: snackBarDuration});

      }else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  downloadBatchSpecificReport(){
    let downloadReport = []
    this.batchSpecificReport.forEach( data => {
      let obj = this.createBatchSpecificReportData(data);
      downloadReport.push(obj);
    })
    const ws1: XLSX.WorkSheet = XLSX.utils.json_to_sheet(downloadReport);  
    const wb1: XLSX.WorkBook = XLSX.utils.book_new();  
    XLSX.utils.book_append_sheet(wb1, ws1, 'Summary Report');
    XLSX.writeFile(wb1, 'Batch Specific Summary Report.xlsx');
  }

  createBatchSpecificReportData(data){
    let obj = {
      'Batch Name': data.trainingBatchName,
      'LOB': data.lob,
      'SUB LOB': data.subLob,
      'No. Of Employees': data.noOfEmployee,
      'Start Date': data.trainingBatchStartDate,
      'End Date': data.trainingBatchEndDate,
      'Current Status': data.trainingBatchStatus.replace(/_/g, ' '),
      'Topics Yet to start Percent': data.yetToStartPercent,
      'Topics In Progress Percent': data.inProgressPercent,
      'Topics Completed Percent': data.completedPercent,
      'Topics Overdue Percent': data.overduePercent,
      'Overall Attendance': data.attendancePercentage,
      'Average batch Score': data.avgBatchScore
    }
    return obj;
  }

  reset(){
    this.form.reset();
    this.createForm();
    this.batchSpecificReport = [];
    this.showReport = false;
    this.trainingBatchList = [];
  }
}
