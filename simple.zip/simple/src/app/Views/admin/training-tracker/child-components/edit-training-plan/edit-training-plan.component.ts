import { Component, OnInit } from '@angular/core';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import { appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables } from '../../../../../app.constants';

@Component({
  selector: 'app-edit-training-plan',
  templateUrl: './edit-training-plan.component.html',
  styleUrls: ['../training-component.scss']
})
export class EditTrainingPlanComponent implements OnInit {

  public lobList = [];
  public subLobList = [];
  public lobConfig;
  public subLobConfig;
  public lob;
  public subLob;
  public trainingPlanList = [];
  public showPreviewFlag = false;
  public currentPage = 1;
  public itemsPerPage = 6;

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private loader: AppLoaderService,
    private router: Router
  ) {
    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.lobConfig = {
      ... configObj,
      displayKey:"lobName",
      placeholder:'Select LOB',
      limitTo: this.lobList.length,
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      ...configObj,
      displayKey:"subLobName",
      placeholder:'Select Sub LOB',
      limitTo: this.subLobList.length,
      searchOnKey: 'subLobName'
    }
   }

  ngOnInit() {
    this.getAllLob();
  }

  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  getSubLob(lob){
    this.loader.open();
    this.subLobList = [];
    this.subLob = [];
    this.showPreviewFlag = false;
    this.trainingPlanList = [];
    if(lob){
      this.adminService.getSubLob(lob.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }    
  }

  getTrainingPlan(subLob){
    this.loader.open();
    this.trainingPlanList = [];
    this.showPreviewFlag = false;
    if(subLob){
      this.adminService.getTrainingPlan(subLob.subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }else{
          if(res.length> 0){
            this.trainingPlanList = res;
            this.showPreviewFlag = true;
          }
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }
  }

  deactivateTrainingPlan(data){
    this.loader.open();
    data.trainingPlanStatus = '';
      this.adminService.deactivateTrainingPlan(data)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return;
        } else{
          this.snackBar.open('Training Plan Deactivated successfully', 'OK', {duration: snackBarDuration});
          this.getTrainingPlan(this.subLob);
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
  }

}
