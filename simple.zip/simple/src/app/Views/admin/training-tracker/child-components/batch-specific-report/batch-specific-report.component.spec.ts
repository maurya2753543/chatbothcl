import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BatchSpecificReportComponent } from './batch-specific-report.component';

describe('BatchSpecificReportComponent', () => {
  let component: BatchSpecificReportComponent;
  let fixture: ComponentFixture<BatchSpecificReportComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BatchSpecificReportComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BatchSpecificReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
