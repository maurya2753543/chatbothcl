import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { AdminService } from '../../../admin.service';
import { MatSnackBar } from '@angular/material';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { Router } from '@angular/router';
import * as XLSX from 'xlsx';
import { appTrainingBatchStatus, appGenericErr, snackBarDuration, appSessionErr, resetLocalStorage, appVariables, digitPattern } from '../../../../../app.constants';
import * as cloneDeep from 'lodash/cloneDeep';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-create-training-batch',
  templateUrl: './create-training-batch.component.html',
  styleUrls: ['../training-component.scss']
})
export class CreateTrainingBatchComponent implements OnInit {

  @ViewChild('traineeFile', { static: false }) traineeFile: ElementRef;
  public trainingBatchForm:FormGroup;
  public lobList = [];
  public subLobList = [];
  public batchTrainerList = [];
  public trainingPlanList = [];
  public lobConfig;
  public subLobConfig;
  public batchTrainerConfig;
  public trainingPlanConfig;
  public trainingBatchStatus = appTrainingBatchStatus;
  public file:File;
  public arrayBuffer:any;
  public selectedFile: any;
  public currentDate = new Date();
  public minDate;

  constructor(
    private adminService: AdminService,
    private snackBar: MatSnackBar,
    private fb: FormBuilder,
    private loader: AppLoaderService,
    private router: Router
  ) { 
    this.minDate = new Date(new Date().setDate(this.currentDate.getDate()));

    let configObj = {
      search:true,
      height: '200px',
      customComparator: ()=>{},
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder:'Search'
    }
    this.lobConfig = {
      ... configObj,
      displayKey:"lobName",
      placeholder:'Select LOB',
      limitTo: this.lobList.length,
      searchOnKey: 'lobName'
    }
    this.subLobConfig = {
      ...configObj,
      displayKey:"subLobName",
      placeholder:'Select Sub LOB',
      limitTo: this.subLobList.length,
      searchOnKey: 'subLobName'
    }
    this.batchTrainerConfig = {
      ...configObj,
      displayKey:"user",
      placeholder:'Select Batch Trainer',
      limitTo: this.batchTrainerList.length,
      searchOnKey: 'user'
    }
    this.trainingPlanConfig = {
      ...configObj,
      displayKey:"trainingPlanName",
      placeholder:'Select Training Plan',
      limitTo: this.trainingPlanList.length,
      searchOnKey: 'trainingPlanName'
    }
  }

  ngOnInit() {
    this.createTrainingBatchForm();
    this.getAllLob();
    this.getBatchTrainerList();
  }

  createTrainingBatchForm(){
    this.trainingBatchForm = this.fb.group({
      trainingBatchName: ['', [Validators.required, Validators.maxLength(100)]],
      lob: [[],Validators.required],
      subLob: [[],Validators.required],
      startDate: ['', Validators.required],
      noOfDays: [null, [Validators.required, Validators.pattern(digitPattern)]],
      endDate: ['', Validators.required],
      batchTrainer: [[],Validators.required],
      traineeList: [[], Validators.required],
      status: [''],
      trainingPlan: [[], Validators.required],
      includeWeekends: [true, Validators.required],
      // excludeWeekends: [false, Validators.required]
    })
  }
  getAllLob(){
    this.loader.open();
    this.adminService.getAllLob()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.lobList = res;
        }
        this.lobConfig.limitTo = this.lobList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }
  getSubLob(lob){
    this.loader.open();
    this.trainingBatchForm.get('subLob').setValue([]);
    this.subLobList = [];
    if(lob){
      this.adminService.getSubLob(this.trainingBatchForm.get('lob').value.lobName)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('LOB not found.', 'OK', {duration: snackBarDuration});
        }else{
          this.subLobList = res;
          this.subLobConfig.limitTo = this.subLobList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }else{
      this.loader.close();
    }    
  }

  setEndDate(){
    let days = null;
    let startDate = cloneDeep(this.trainingBatchForm.get('startDate').value);
    let endDate = null;
    let count = 0;
    if(this.trainingBatchForm.get('noOfDays').value != null){
      days = this.trainingBatchForm.get('noOfDays').value - 1;
      if(this.trainingBatchForm.get('includeWeekends').value == false){
        while(count < days){
          endDate = new Date(startDate.setDate(startDate.getDate() + 1));
          if(endDate.getDay() != 0 && endDate.getDay() != 6){
             count++;
          }
        }
      }else{
        endDate = new Date().setDate(startDate.getDate()+ days);
      }
      this.trainingBatchForm.get('endDate').setValue(new Date(endDate));
    }
  }

  getBatchTrainerList(){
    this.loader.open();
    this.adminService.getUserByRole('ADMIN')
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else if (res == null){
        this.snackBar.open('Batch Trainers not found.', 'OK', {duration: snackBarDuration});
      }else{
        if(res.length> 0){
          this.batchTrainerList = res;
          this.batchTrainerList.forEach(trainer => {
            let combinedStr = trainer.userName + ' ' + trainer.userId;
            trainer['user'] = combinedStr;
          })
        }
        this.batchTrainerConfig.limitTo = this.batchTrainerList.length;
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  getTrainingPlan(){
    this.loader.open();
    this.trainingBatchForm.get('trainingPlan').setValue([]);
    this.trainingPlanList = [];
    if(this.trainingBatchForm.get('subLob')){
      this.adminService.getTrainingPlan(this.trainingBatchForm.get('subLob').value.subLobId)
      .subscribe(res => {
        this.loader.close();
        if(res == 'ERROR'){
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
          return
        }else if (res == null){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }else{
          if(res.length> 0){
            this.trainingPlanList = res;
          }
          this.trainingPlanConfig.limitTo = this.trainingPlanList.length;
        }
      }, err => {
        this.loader.close();
        if(err.status == '401'){
          this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
          resetLocalStorage();
          this.router.navigate([appVariables.loginPageUrl]);
        }else if(err.status == '404'){
          this.snackBar.open('Training Plans not found.', 'OK', {duration: snackBarDuration});
        }
        else{
          this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        }
      })
    }
  }

  parseFile(event){
    this.selectedFile = event.target.files;
    if(event.target.files.length > 0) {
      this.file= event.target.files[0]; 
      let fileReader = new FileReader();
      let parsedFile = [];
      let userArray = [];
      fileReader.onload = (e) => {
        this.arrayBuffer = fileReader.result;
        let data = new Uint8Array(this.arrayBuffer);
        let arr = new Array();
        for(var i = 0; i != data.length; ++i) arr[i] = String.fromCharCode(data[i]);
        let bstr = arr.join("");
        let workbook = XLSX.read(bstr, {type:"binary"});
        let first_sheet_name = workbook.SheetNames[0];
        let worksheet = workbook.Sheets[first_sheet_name];
        parsedFile = XLSX.utils.sheet_to_json(worksheet,{raw:true});
        parsedFile.forEach(user => {
          var values = Object.keys(user).map(function(e) {
            userArray.push(...user[e]);
          })
        });
        this.trainingBatchForm.get('traineeList').setValue(userArray);
      }
      fileReader.readAsArrayBuffer(this.file);
    }else{
      this.trainingBatchForm.get('traineeList').setValue('');
    }
  }

  createTrainingBatchPostData(){
    //let isWeekendIncluded = 'Yes';
    let trainerList = [];
    // if(this.trainingBatchForm.get('includeWeekends').value == false){
    //   isWeekendIncluded = 'No';
    // }
    this.trainingBatchForm.get('batchTrainer').value.forEach(trainer => {
      trainerList.push(trainer.userId);
    })
    let data = {
      trainingBatchId: '',
      trainingBatchName: this.trainingBatchForm.get('trainingBatchName').value,
      subLob: this.trainingBatchForm.get('subLob').value,
      trainingBatchStartDate: new DatePipe('en-US').transform(this.trainingBatchForm.get('startDate').value, 'yyyy-MMM-dd'),
      numberOfDays: this.trainingBatchForm.get('noOfDays').value,
      trainingBatchEndDate: new DatePipe('en-US').transform(this.trainingBatchForm.get('endDate').value, 'yyyy-MMM-dd'),
      batchTrainers: trainerList,
      traineeList: this.trainingBatchForm.get('traineeList').value,
      trainingBatchStatus: this.trainingBatchForm.get('status').value,
      trainingPlan: this.trainingBatchForm.get('trainingPlan').value,
      isWeekendIncluded: this.trainingBatchForm.get('includeWeekends').value
    }
    this.saveTrainingBatch(data);
  }

  private saveTrainingBatch(data){
    this.loader.open();
      this.adminService.createTrainingBatch(data)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      } else{
        this.snackBar.open('Training Batch added successfully', 'OK', {duration: snackBarDuration});
        this.resetData();
      }
    }, err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }else if(err.status == '400'){
        if(err.error.Error){
          this.snackBar.open(err.error.Error, 'OK', {duration: snackBarDuration});
        }else{
          this.snackBar.open('Invalid Data', 'OK', {duration: snackBarDuration});
        }
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  resetData(){
    this.trainingBatchForm.reset();
    this.createTrainingBatchForm();
    if(this.traineeFile){
      this.traineeFile.nativeElement.value = null;
    }
    this.selectedFile = null;
  }
}
