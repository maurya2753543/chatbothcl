import { Component, OnInit, ViewChild, Directive, Input, ElementRef, ViewChildren, Inject } from '@angular/core';
import { QuizService } from '../quiz.service';
import { MatSnackBar } from "@angular/material";
import { Router, ActivatedRoute } from '@angular/router';
import { appSessionErr, appGenericErr, appVariables, resetLocalStorage, localStorageVariables, snackBarDuration } from 'src/app/app.constants';
import { AppLoaderService } from '../../../shared/services/app-loader/app-loader.service';
import { CountdownComponent } from 'ngx-countdown';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';

export interface DialogData {
  result: string;
}

@Component({
  selector: 'app-question-set',
  templateUrl: './question-set.component.html',
  styleUrls: ['./question-set.component.scss']
})
export class QuestionSetComponent implements OnInit {

  @ViewChild('countdown', { static: false }) counter: CountdownComponent;

  public selectedAssessmentId;
  public questionList = [];
  public questionSet;
  public saveQuestionSet;
  public quizDuration;
  public selectedAnswerArray = [];
  public saveQuestionList = [];
  public tempMatchAnswer = [];
  public matchCorrectAnswer = [];
  public userName = '';
  public user = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
  public bufferMatchAnswerArray = [];
  public currentPage:any;
  public quizSubmitted = false;

  constructor(
    private quizService: QuizService,
    private loader: AppLoaderService,
    private snackBar: MatSnackBar,
    private router: Router,
    private route: ActivatedRoute,
    public dialog: MatDialog
  ) { }

  ngOnInit() {
    this.quizSubmitted = false;
    this.userName = this.user.userName;
    this.selectedAssessmentId = this.route.snapshot.paramMap.get('id');
    this.getQuestionSet();
  }

  getQuestionSet(){
    this.loader.open();
   this.quizService.getQuestionSet(this.selectedAssessmentId)
   .subscribe(res => {
    this.loader.close();
     if(res == 'ERROR'){
      this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      return;
     }
     else if(res == null){
      this.snackBar.open('There is no assessment for selected assessment Id.', 'OK', {duration: snackBarDuration});
      this.router.navigate(['/quiz']);
     } else{
       this.quizSubmitted = false;
      this.questionSet = res;
      this.questionSet.questionList.forEach(question => {
        let obj = {...question};
        this.questionList.push(obj);
      })
      this.questionList.forEach(question => {
        let obj = {...question};
        this.saveQuestionList.push(obj);
        if(question.type == 'Match'){
          this.setMatchSelectedAnswerArray(question.questionId);
        }
      })
     }
   },err => {
     this.loader.close();
    if(err.status == '401'){
      this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
      resetLocalStorage();
      this.router.navigate([appVariables.loginPageUrl]);
    } else{
      this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
    }
   })
  }

  setMatchSelectedAnswerArray(questionId){
    this.saveQuestionList.forEach(question => {
      if(question.questionId == questionId){
        question.selectedAnswer = [];
        question.optionList.forEach( option => {
          let obj = {
            optionId: option.optionId,
            optionName: option.optionName,
            answer: '',
            feedback: option.feedback
          }
          question.selectedAnswer.push(obj);
        })
      }
    })
  }

  getAnswerList(answer){
    if(answer != null){
      this.bufferMatchAnswerArray = answer;
    }
    return false;
  }

  matchOptionSelected(questionId, optionId, event){
    this.saveQuestionList.forEach(question => {
      if(question.questionId == questionId){
        question.selectedAnswer.forEach(ansOpt => {
          if(ansOpt.optionId == optionId){
            ansOpt.answer = event.value;
          }
        })
      }
    })
  }

  selectedAnswer(value, questionId){
    this.saveQuestionList.forEach(question => {
      if(question.questionId == questionId){
        question.optionList.forEach(option => {
          if(option.optionId == value){
            let obj = {...option}
            question.selectedAnswer.push(obj);
          }
        })
        if((question.type == 'Mcq' || question.type == 'Image') && question.selectedAnswer.length > 1){
          question.selectedAnswer = question.selectedAnswer.filter(v => v.optionId == value);
        }
      }
    })
  }

  maqSelectedAnswer(questionId, optionId, event){
    this.saveQuestionList.forEach(question => {
      if(question.questionId == questionId){
        question.optionList.forEach(option => {
          if(event.checked == true){
            if(option.optionId == optionId){
              let obj = {...option}
              question.selectedAnswer.push(obj);
            }
          }
          else if(event.checked == false){
            if(option.optionId == optionId){
              question.selectedAnswer =  question.selectedAnswer.filter(function(opt){
                return opt.optionId !== optionId;
              })
            }
          }
        })
      }
    })
  }

  descriptiveAnswer(event, questionId){
    this.saveQuestionList.forEach(question => {
      if(question.questionId == questionId && question.type == 'Descriptive'){
        question.discriptiveAnswer = event.target.value;
      }
    })
  }

  submitQuiz(e){
    
    if (e["action"] == "done"){
      this.quizDuration = this.questionSet.duration;
      this.saveQuiz('TIMEUP');
    }
    else if (e.type == 'click'){
      this.counter.stop();
      this.quizDuration = ((+this.questionSet.duration * 60 * 1000 ) - (this.counter.left))/60000;
      this.saveQuiz('SUBMIT');
    }else{
      return;
    }
  }

  saveQuiz(eventType:string){
    this.saveQuestionSet = {...this.questionSet};
    this.saveQuestionSet.questionList = [];
    this.saveQuestionList.forEach(question => {
      if(question.type == 'Image'){
        question.imageByte = null;
      }
      let obj = {...question};
      this.saveQuestionSet.questionList.push(obj);
    })
    let saveData = {
      quizId: '',
      quizDate: '',
      hasDiscriptiveQuestion: '',
      attemptedQuestion: '',
      correctQuestion: '',
      wrongQuestion: '',
      quizScore: '',
      quizOutcome: '',
      quizDuration: this.quizDuration,
      questionSet: this.saveQuestionSet
    }
    this.loader.open();
    this.quizService.saveQuiz(saveData)
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return;
      }else{
        ///this.router.navigate(['/quiz']);
        this.openDialog(res.Quiz_Result, eventType);
      }
    }, err => {
      this.loader.close();
      this.quizSubmitted = false;
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      } else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  showFeedback(questionId, optionId){
    let flag = false;
    let count = 0;
    if(this.quizSubmitted){
      this.saveQuestionSet.questionList.forEach(question => {
        if(question.questionId == questionId){
          if(question.selectedAnswer.length > 0){
            question.selectedAnswer.forEach(answer => {
              if(answer.optionId == optionId){
                count++;
              }
            })
          }
        }
      })
      if(count > 0){
        flag = true;
      }
    }else{
      flag = false;
    }
    return flag;
  }

  openDialog(res, eventType): void {
    const dialogRef = this.dialog.open(QuizStatusDialogComponent, {
      width: '400px',
      height: '200px',
      data: {result: res, eventType: eventType}
    });

    dialogRef.afterClosed().subscribe(result => {
      this.quizSubmitted = true;
      //this.router.navigate(['/quiz']);
    });  
  }
  

}

@Component({
  selector: 'app-quiz-status-dialog',
  templateUrl: './quiz-status-dialog.html',
  styleUrls: ['./question-set.component.scss']
})
export class QuizStatusDialogComponent implements OnInit {
  constructor(
    public dialogRef: MatDialogRef<QuizStatusDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData
  ) {
    dialogRef.disableClose = true;
   }

  ngOnInit() {

  }
}

