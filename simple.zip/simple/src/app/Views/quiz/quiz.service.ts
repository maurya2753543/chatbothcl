import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseService } from '../../shared/services/base.service';
import { appApiPaths, localStorageVariables } from 'src/app/app.constants';
import { SharedService } from '../../shared/shared.service';
import { HttpHeaders } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class QuizService {

  public authDetails = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));

  constructor(
    private baseService: BaseService,
    private sharedService: SharedService
  ) { }

  getAssessment(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    this.authDetails = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
    return this.baseService.get(appApiPaths.getAssessmentById + this.authDetails.userDetail.username, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getQuestionSet(assessmentId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    this.authDetails = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
    let url = appApiPaths.getQuestionSet + '?assessmentId=' + assessmentId + '&userId='  +this.authDetails.userDetail.username ;
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  saveQuiz(quizdata): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveQuizDetais, quizdata, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }
}
