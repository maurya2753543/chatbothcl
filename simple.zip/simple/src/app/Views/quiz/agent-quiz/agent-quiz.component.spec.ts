import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AgentQuizComponent } from './agent-quiz.component';

describe('AgentQuizComponent', () => {
  let component: AgentQuizComponent;
  let fixture: ComponentFixture<AgentQuizComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AgentQuizComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AgentQuizComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
