import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ManagerComponent } from './manager.component';
import { ManagerRoutingModule } from './manager-routing.module';
import { AppLoaderComponent } from '../../shared/services/app-loader/app-loader.component';
import { SharedModule } from '../../shared/shared.module';
import { ManageQuizComponent } from './manage-quiz/manage-quiz.component';
import { ManageSubLobComponent } from './manage-quiz/detailTabs/manage-sublob/manage-sublob.component';
import { AddQuestionComponent } from './manage-quiz/detailTabs/add-question/add-question.component';
import { BulkUploadQuestionComponent } from './manage-quiz/detailTabs/bulk-upload-question/bulk-upload-question.component';
import { QuestionComponent } from './manage-quiz/detailTabs/add-question/QuestionComponent';
import { UpdateQuestionComponent, QuestionEditDialogComponent} from './manage-quiz/detailTabs/update-question/update-question.component';
import { UpdateQuestionBankComponent } from './manage-quiz/detailTabs/update-question-bank/update-question-bank.component';
import { ManageAssessmentComponent } from './manage-assessment/manage-assessment.component';
import { AddAssessmentComponent } from './manage-assessment/tabDetails/add-assessment/add-assessment.component';
import { AutoAssessmentComponent } from './manage-assessment/tabDetails/auto-assessment/auto-assessment.component';
import { ViewAssessmentComponent, EditAssessmentDialogComponent} from './manage-assessment/tabDetails/view-assessment/view-assessment.component';
import { AssessmentEvaluationComponent } from './assessment-evaluation/assessment-evaluation.component';

import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { FlexLayoutModule } from '@angular/flex-layout';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatTabsModule } from '@angular/material/tabs';
import { MatRadioModule } from '@angular/material/radio';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule, MatNativeDateModule, MatIconModule } from '@angular/material';
import { NgxPaginationModule } from 'ngx-pagination';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { MatMenuModule } from '@angular/material/menu';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { MatDividerModule } from '@angular/material/divider';
import { MatDialogModule } from '@angular/material/dialog';


@NgModule({
  declarations: [
    ManagerComponent,
    AssessmentEvaluationComponent,
    ManageQuizComponent,
    ManageSubLobComponent,
    BulkUploadQuestionComponent,
    AddQuestionComponent,
    QuestionComponent,
    UpdateQuestionComponent,
    QuestionEditDialogComponent,
    UpdateQuestionBankComponent,
    ManageAssessmentComponent,
    AddAssessmentComponent,
    AutoAssessmentComponent,
    ViewAssessmentComponent,
    EditAssessmentDialogComponent
  ],
  imports: [
    CommonModule,
    MatCardModule,
    MatSelectModule,
    MatExpansionModule,
    SelectDropDownModule,
    NgxPaginationModule,
    MatAutocompleteModule,
    MatMenuModule,
    MatTooltipModule,
    FlexLayoutModule,
    MatDialogModule,
    MatRadioModule,
    MatSlideToggleModule,
    MatTabsModule,
    NgMultiSelectDropDownModule,
    MatFormFieldModule,
    MatDividerModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatInputModule,
    MatCheckboxModule,
    MatButtonModule,
    ManagerRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule
  ],
  entryComponents: [
    AppLoaderComponent,
    QuestionEditDialogComponent,
    EditAssessmentDialogComponent
  ]
})
export class ManagerModule { }
