import { Component, OnInit } from '@angular/core';
import { ManagerService } from '../../../manager.service';
import { AppLoaderService } from '../../../../../shared/services/app-loader/app-loader.service';
import { MatSnackBar } from '@angular/material';
import { Router } from '@angular/router';
import { appSessionErr, snackBarDuration, resetLocalStorage, appVariables, appGenericErr } from '../../../../../app.constants';

@Component({
  selector: 'app-manage-sublob',
  templateUrl: './manage-sublob.component.html',
  styleUrls: ['./manage-sublob.component.scss']
})
export class ManageSubLobComponent implements OnInit {

  public lob = {
    lobName : ''
  };
  public subLob = '';

  constructor(
    private managerService: ManagerService,
    private loader: AppLoaderService,
    private snackBar: MatSnackBar,
    private router: Router
  ) { }

  ngOnInit() {
    this.getUserLob();
  }

  getUserLob(){
    this.loader.open();
    this.managerService.getLobBuUserId()
    .subscribe(res => {
      this.loader.close();
      if(res == 'ERROR'){
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else{
        this.lob = res;
      }
      
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else if(err.status == '404'){
        this.snackBar.open('No LOB found for logged in User', 'OK', {duration: snackBarDuration});
      }
        else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  saveSubLob(){
    this.loader.open();
    let subLobData = {
      subLobName: this.subLob,
      lob: {
        lobName: this.lob.lobName
      }
    }
    this.managerService.saveSubLob(subLobData)
    .subscribe(res => {
      if(res == 'ERROR'){
        this.loader.close();
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
        return
      }else{
        this.loader.close();
        this.snackBar.open('Sub LOB Saved Successfully', 'OK', {duration: snackBarDuration});
        this.resetData();
      }
      
    },err => {
      this.loader.close();
      if(err.status == '401'){
        this.snackBar.open(appSessionErr, 'OK', {duration: snackBarDuration});
        resetLocalStorage();
        this.router.navigate([appVariables.loginPageUrl]);
      }
      else if(err.status == '400'){
        this.snackBar.open('Invalid SUB LOB Name', 'OK', {duration: snackBarDuration});
      }
        else{
        this.snackBar.open(appGenericErr, 'OK', {duration: snackBarDuration});
      }
    })
  }

  resetData(){
    this.subLob = '';
  }

}
