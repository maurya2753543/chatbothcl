import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ManageSubLobComponent } from './manage-sublob.component';

describe('ManageLobComponent', () => {
  let component: ManageSubLobComponent;
  let fixture: ComponentFixture<ManageSubLobComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ManageSubLobComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageSubLobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
