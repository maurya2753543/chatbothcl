import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { BaseService } from '../../shared/services/base.service';
import { appApiPaths, localStorageVariables } from '../../app.constants';
import { SharedService } from '../../shared/shared.service';

@Injectable({
  providedIn: 'root'
})
export class ManagerService {

  constructor(
    private baseService: BaseService,
    private sharedService: SharedService
  ) { }

  getLobBuUserId(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let user = JSON.parse(localStorage.getItem(localStorageVariables.AuthInfo));
    let userId = user.userDetail.username;
    return this.baseService.get(appApiPaths.getLobByUserId + userId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }


  saveSubLob(subLobData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveSubLob, subLobData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getSubLob(lobName): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getSubLob + lobName , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getQuestionBank(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionBank + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAllQuestionBank(subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllQuestionBank + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAllCategory(): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAllCategory, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addQuestion(questionData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addQuestion, questionData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getQuestions(questionBnakName, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestions + questionBnakName +'&subLobId='+ subLobId , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getQuestionById(questionBnakName, subLobId, questionId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getQuestionById + questionBnakName +'&subLobId='+ subLobId + '&questionId=' + questionId , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  updateQuestion(questonData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.updateQuestion, questonData , options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  updateQuestionBank(data): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.put(appApiPaths.updateQuestionBank, data, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getTrainingBatchBySubLob(subLobId, triggerDate?:any): Observable<any> {
    let options = this.sharedService.getBearerToken();
    let url = appApiPaths.getTrainingBatchBySubLob + subLobId + '&triggerDate=' + '';
    if(triggerDate){
      url = url + triggerDate;
    }
    return this.baseService.get(url, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addAssessmentDetails, assessmantData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  addAutoAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.addAutoAssessmentDetails, assessmantData, options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getAssessmentForEdit(fromDate, toDate, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getAssessmentForEdit + fromDate + '&endDate=' + toDate + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  editAssessmentDetails(assessmantData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.editAssessmentDetails, assessmantData, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getFailedUserList(assessmantId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getFailedUserList + assessmantId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204 || res == []){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            });
  }

  getDescriptiveAssessment(userId, subLobId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getDescriptiveAssessment + userId + '&subLobId=' + subLobId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getDescriptiveQuestion(assessmentId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getDescriptiveQuestion + assessmentId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  saveDescriptiveQuestion(questonData): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.post(appApiPaths.saveDescriptiveQuestion, questonData , options)
            .map((res) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }

  getTopicByCategoryId(categoryId): Observable<any> {
    let options = this.sharedService.getBearerToken();
    return this.baseService.get(appApiPaths.getTopicByCategoryId + categoryId, options)
            .map((res: any) => {
              if(res.status == 200){
                return res.body;
              } else if(res.status == 204){
                return null;
              }
              else{
                return 'ERROR';
              }
            })
            .catch((error: Response) => Observable.throw(error))
            .finally(() => {
            }); 
  }
}
