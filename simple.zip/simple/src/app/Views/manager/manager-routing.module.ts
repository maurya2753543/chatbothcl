import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ManagerComponent } from './manager.component';
import { ManageQuizComponent } from './manage-quiz/manage-quiz.component';
import { ManageAssessmentComponent } from './manage-assessment/manage-assessment.component';
import { QuestionComponent } from './manage-quiz/detailTabs/add-question/QuestionComponent';
import { AssessmentEvaluationComponent } from './assessment-evaluation/assessment-evaluation.component';

const routes: Routes = [
  { path: '', component: ManagerComponent },
  { path: 'manage-quiz', component: ManageQuizComponent },
  { path: 'manage-assessment', component: ManageAssessmentComponent },
  { path: 'add-question', component: QuestionComponent},
  { path: 'evaluation', component: AssessmentEvaluationComponent},
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ManagerRoutingModule { }
