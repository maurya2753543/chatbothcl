import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Input, AfterViewInit, ViewChild, ViewChildren, QueryList, ElementRef } from '@angular/core';


import { ChatService } from '../services/chat/chat.service';
import { Question } from '../models/question';
import { FormGroup, FormControl, Validators, FormBuilder } from '@angular/forms'
import { any } from 'async';
import { Message } from '../models/message';
import { ArrayType, ElementSchemaRegistry } from '@angular/compiler';
import { Router } from '@angular/router';
import { ExcelService } from '../services/ExcelService';
import { MediaChange, MediaObserver } from '@angular/flex-layout'
import { from } from 'rxjs';
import { Subscription } from 'rxjs';
import { AppLoaderService } from '../shared/services/app-loader/app-loader.service';
interface user {
  title: string;
  response_type: string;

}
export interface LOB {
  lobName: string;
  status: string;

}

@Component({
  selector: 'app-chatbotdialog',
  templateUrl: './chatbotdialog.component.html',
  styleUrls: ['./chatbotdialog.component.scss']
})
export class ChatbotdialogComponent implements OnInit, OnDestroy {
  user: any;
  public message: Message;
  public messages: Message[];
  userdetailsarr: any[];
  ShowAnswer = false;
  clicked: boolean;
  clickedsub: boolean;
  clickedcat: boolean;
  show: boolean;
  clickedshowanswer: boolean;
  dowenloadreport: any[];
  mediaSub: Subscription;
  deviceXs: boolean;

  // Code for Scrolling
  //@ViewChild('chatlist', { read: ElementRef }) chatList: ElementRef;
  // Code for Scrolling
  @ViewChild('chatlist', { read: ElementRef, static: true }) chatList: ElementRef;
  @ViewChildren(ChatbotdialogComponent, { read: ElementRef }) chatItems: QueryList<ChatbotdialogComponent>;


  inputarray: any = [];
  Categoryresult: any;
  [x: string]: any;
  msg!: string;
  watsonresponse: any;//response or result coming from watson
  selectans: string;
  inputtext: string = "intial value"
  selectedlobid: any;
  selectcateid: any;
  UserValue: any;
  lastdiv = false;
  NextQuesDis = false;
  categorylist: any = [];
  loading: Boolean = false;

  reactiveForm: FormGroup;
  CustomeStrong = false;
  response: Message = {
    text: '',
    description: '',
    content: '',
    show: true,
    correctAnswer: '',


  };
  questions: Question = {
    questionText: '',
    optionList: '',
    optionName: '',
    optionId: ''


  };
  diableflag = any;
  inpuString: string;
  @ViewChild('scroll', { static: true }) scroll: any;
  displayElement = false;
  lastresult: any;
  Buttonend = false;
  hideques: Boolean = false

  watsonarr: any = [];
  last: any = [];
  text: any;
  dynamicres = false;
  Nomsg: any;
  ShowAnswer1 = false;
  clickedDownload: boolean;

  qus: any;
  excel = [];
  assesmentid: any;
  selectedValue = null;
  username: any;
  inputform: FormGroup
  lineofbus: any;
  linebus: any;
  Howcan = false;
  form: FormGroup = new FormGroup({});
  formcate: FormGroup = new FormGroup({});
  constructor(private chatservice: ChatService,
    private loader: AppLoaderService,
    private fb: FormBuilder,
    public dialog: MatDialog,
    private _formBuilder: FormBuilder,
    private router: Router,
    private excelService: ExcelService,
    public mediaObserver: MediaObserver) {
    this.getUserCategoryReport()

    this.message = new Message('')
    this.messages = [
      new Message('')
    ];


    this.username = JSON.parse(localStorage.getItem('AuthInfo')).userName
    console.log(this.username, 'username value value')
    this.getlob()
    this.sendmsg()
    // this.lastassessment()
    // this.getUserCategoryReport()


    this.form = fb.group({
      lobName: ['', [Validators.required]],
      assessmentName: ['', [Validators.required]]

    })
    this.formcate = fb.group({
      _id: ['', [Validators.required]],


    })
    this.inputform = this.fb.group({
      inputmessage: [''],


    })

  }

  sessionId: any;
  ngOnInit(): void {
    console.log(" details of category list", this.getCategorylist())
    this.getCategorylist();
    this.inputarray = []
    this.watsonarr = []
    this.inputarray.push(this.inputform.value.inputmessage)
    this.watsonarr.push(this.watsonresponse);
    this.mediaSub = this.mediaObserver.media$.subscribe((result: MediaChange) => {
      console.log(result.mqAlias);
      this.deviceXs = result.mqAlias === 'xs' ? true : false;
    })



  }
  ngOnDestroy() {
    this.mediaSub.unsubscribe()

  }

  sendmsg() {
    console.log('checking session id------------')
    this.chatservice.setSession().subscribe((response: any) => {
      this.sessionId = response.result.session_id
      sessionStorage.setItem('sessionId', this.sessionId)

      this.sendmsgtowatson()


    })

  }
  sendmsgtowatson() {
    console.log('message+++++++++', this.message)
    let data = {
      message: this.message.content != '' ? this.message.content : '',
      session_id: sessionStorage.getItem('sessionId'),
      token: JSON.parse(localStorage.getItem('AuthInfo')).access_token,
      userid: JSON.parse(localStorage.getItem('AuthInfo')).userDetail.username
    }
    console.log(data, 'checking session id------------')
    this.loading = true
    this.chatservice.sendmsgtowatson(data).subscribe((result: any) => {

      this.loading = false
      // this.messages.push(result[0]);

      console.log(this.messages, "reached to watson")
      var title = '', description = '';

      // this.giveout=result;
      console.log(result, 'array result')
      if (result && result.status && result.status == '201') {
        sessionStorage.setItem('sessionId', result.result.session_id)
        this.message.content = result.message
        this.callingsendmsgtowatson()
      }
      else if (result && result[0].text == 'details') {
      //  this.userdetails();
        this.lastdiv = false;
       // this.messages.push(this.userdetails())
      // this.messages.push(this.lastresult[0])



      }
      // else if (result && result[0].text == 'last') {

      //   // this.lastdiv=true;
      //   console.log("last result reacged ", this.lastresult)
        






      // }

      else if (result && result[0].text == "customquestions") {
        this.customQuestions()
      }
      else if (result && result[0].text == "nextquestion") {

        //  console.log('it reached to next question-------------------')
        this.messages.push(this.qus[0])
        console.log('it reached to next question-------------------', this.messages)

        this.qus.splice(0, 1)


      }
      else if (result && result[0].type == "showmedetails") {
console.log('reached here at show result00')
        
        this.chatservice.getUserAssessmentHistory(this.selectedlobid, this.assesmentid, 'All').subscribe((detailsresult: any) => {
console.log('details result show me details',detailsresult)
          detailsresult.forEach(element => {
            console.log(element, 'element++++++++++++++++++++++++')
            this.messages.push(element)
            this.scrollToBottom();
          });
       //   this.form.reset()
       result.forEach(element => {

        this.messages.push(element);
        // }
      });

        })
       
      }
      else if (result && result[0].text == "last") {
        console.log('reached here at show result00')
      
        this.chatservice.getUserAssessmentHistory(0, 0, 'Last').subscribe((result: any) => {

          this.lastresult = result
          this.messages.push(this.lastresult[0])
          this.message.content="scorerelevantquestion"
          this.sendmsgtowatson()
          this.message=new Message('')
          
          console.log("last assessment 999999)))))", this.lastresult)
    
        })
      
               
          }


      else if(result && result[0].type=='strongpoint') {
        this.messages.push(result[0])

        this.message.content="strongpointrelevantquestion"
        this.sendmsgtowatson()
        this.message=new Message('')
      }
      else if(result && result[0].type=='weakpoint') {
        this.messages.push(result[0])

        this.message.content="weakpointrelevantquestion"
        this.sendmsgtowatson()
        this.message=new Message('')
      }
      else if(result && result[0].type=='highscore') {
        this.messages.push(result[0])

        this.message.content="highscorerelevantquestion"
        this.sendmsgtowatson()
        this.message=new Message('')
      }
      else if(result && result[0].type=='lowscore') {
        this.messages.push(result[0])

        this.message.content="lowscorerelevantquestion"
        this.sendmsgtowatson()
        this.message=new Message('')
      }
        // strongpointrelevantquestion
else{

        console.log('final result-----------------------------', result)


        result.forEach(element => {

          this.messages.push(element);
          // }
        });


        console.log("watson array", this.watsonresponse)




      }
    })



  }
  callingsendmsgtowatson() {
    this.sendmsgtowatson()
    this.message = new Message('')
  }
  getlob() {
    this.chatservice.fetchlob().subscribe((Lob: any) => {

      this.linebus = Lob;
    })
  }
  lobselect(value) {
    this.selectedlobid = value
    //this.form.setValue(value)

    this.getUserAssessmentByLob()
    // console.log(value,'value+++++++++++++++++++++++++++')
  }
  Catgoryselect(value) {

    this.selectcateid = value


  }
  selectAssesement(value) {
    this.assesmentid = value
    //  this.form.setValue(this.assesmentid)
    // this.userdetails()


  }
  getUserAssessmentByLob() {
    // this.selectedlobid=""
    console.log('reached in getuserassessment')
    this.chatservice.getUserAssessmentByLob(this.selectedlobid).subscribe((result: any) => {

      this.lineofbus = result;

    })
  }

  userdetails() {
    // this.assesmentid=""
    console.log(this.selectedlobid, this.assesmentid, 'allll------------------------------------')

    /* with watson */

    this.message.content="showselecteddetail"
    this.sendmsgtowatson()
    this.message=new Message('')





  //  this.chatservice.getUserAssessmentHistory(this.selectedlobid, this.assesmentid, 'All').subscribe((detailsresult: any) => {

  //         detailsresult.forEach(element => {
  //           console.log(element, 'element++++++++++++++++++++++++')
  //           this.messages.push(element)
  //           this.scrollToBottom();
  //         });
  //      //   this.form.reset()
    
  //       })
   
  }


  // lastassessment() {

  //   this.chatservice.getUserAssessmentHistory(0, 0, 'Last').subscribe((result: any) => {

  //     this.lastresult = result

  //     console.log("last assessment 999999)))))", this.lastresult)

  //   })

  // }


  getCategorylist() {

    this.chatservice.getCategoryList().subscribe((result: any) => {

      this.categorylist = result
    })
  }
  getUserCategoryReport() {

    this.chatservice.getUserCategoryReport().subscribe((result: any) => {

      this.Categoryresult = result;
      result.forEach(element => {

        let obj = { Category: element._id, TotalQuestion: element.total, CorrectQuestion: element.correct, IncorrectQuestion: element.incorrect, PartiallyCorrect: element.partiallyCorrect, EvaluationPending: element.pendingQuestion }

        this.excel.push(obj)

      });


    })
  }

  customQuestions() {
    this.chatservice.getQuestions().subscribe((result: any) => {
      console.log(result, 'customquestions-->>>>>>>>>>>')
      this.qus = result;
      this.messages.push(result[0])
      this.qus.splice(0, 1)
      console.log(this.messages, 'customquestions+++++++++++++++++++++++')

    })



  }
  SubmitCategoryReport(obj, i) {
    obj.clickedcat = true
    this.messages[i] = obj
    //this.getUserCategoryReport() 
    this.getUserCatWiseReport()

  }
  onClick(value, obj, index) {

    console.log(value, 'value++++++++++++++++')

    obj.disablebutton = true
    this.messages[index] = obj
    var content = value == "Yes" ? value = 'Yes' : (value == "No" ? value = "No" : value)
    this.message.content = content
    this.messages.push(this.message)
    this.sendmsgtowatson()
    this.message = new Message('')
  }
  onClinklink() {

   this.customQuestions()
  }






  ShowAns(obj, index) {
   // this.loading=false;
    obj.clickedshowanswer = true
    this.messages[index] = obj

    if (this.qus.length > 0) {
      this.ShowAnswer = true;
     // this.loading=false;
      this.message.content = "fetch more question"
      this.sendmsgtowatson()
      this.message = new Message('')
    }
    else {
      //this.loading=false;
      this.ShowAnswer = true;
      this.message.content = "complete"
      this.hideques = true;
      this.sendmsgtowatson()
      this.message = new Message('')

    }





  }
  ShowAns1() {
    this.ShowAnswer1 = true;


  }




  SaveOption(obj, i) {
    console.log(obj, i, 'savedoptions+++++++++++++')
    obj.clickedsub = true
    console.log("my setelected value here" , this.selectedlobid)
    console.log("my setelected value here aassment" , this.selectedlobid)


    this.messages[i] = obj

    // console.log("user details must", this.userdetails())
      this.userdetails()





  }
  ngAfterViewInit() {
    this.chatItems.changes.subscribe(elements => {
     // this.loading=false;
      this.scrollToBottom();
    });
  }

  getUserCatWiseReport() {
    console.log(this.selectcateid, 'getselectedcateit++++++++++++++++++++++++++++++++')
    // send category name
    this.chatservice.getUserCatWiseReport(this.selectcateid).subscribe((result) => {
      console.log(this.dowenloadreport, 'getUserCatWiseReportresult  5555555_999')

      this.dowenloadreport = result;


      result.forEach(element => {
        this.messages.push(element)
      //  this.loading=false;
        this.scrollToBottom();

      });
    })
  }
  sendcustommsgtowatson() {

    this.messages.push(this.message);

    this.sendmsgtowatson()
    this.loading=false;
    this.scrollToBottom();


    this.message = new Message('');
  }
  exportAsXLSX(obj, i): void {
    obj.clickedDownload = true
    this.messages[i] = obj
    // var thanks_download = obj == "Download" 
    // this.message.thanks_download = thanks_download
    // this.messages.push(this.message)

    this.excelService.exportAsExcelFile(this.excel, 'Question Category Report')
    console.log("best category report", this.getUserCategoryReport())



  }

  private scrollToBottom(): void {
    try {
   //   this.loading=false;
      this.chatList.nativeElement.scrollTop = this.chatList.nativeElement.scrollHeight;
    }
    catch (err) {
      console.log('Could not find the "chatList" element.');
    }
  }
 

}