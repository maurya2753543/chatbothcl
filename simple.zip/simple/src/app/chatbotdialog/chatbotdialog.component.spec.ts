import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ChatbotdialogComponent } from './chatbotdialog.component';

describe('ChatbotdialogComponent', () => {
  let component: ChatbotdialogComponent;
  let fixture: ComponentFixture<ChatbotdialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ChatbotdialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ChatbotdialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
