
var globalVariable = "";
var globalqueryarray = []
var i = 1;
var retobj = {};
localStorage.clear();
var popupOpen = true

$(function () {
        $("#btnShowPopup").click(function () {
            if(popupOpen == false){
                var title = "EVA Healthcare Assistant";
        
                $("#MyPopup .modal-title").html(title);
                $("#MyPopup").modal("show");
                $(".chat_box").css("right", "10px");
        
                (function ($) {
                    $.ajax({
                        url: 'http://localhost:3000/api/session',
                        // url: 'https://eva-healthcare-bot.mybluemix.net/api/session',
                        type: 'Get',
                        success: function (result) {
                            sessionStorage.setItem('Sessionid', result.data.session_id)
                            send_msg('1')
                        }
                    })
                })($)
            }
           
        });
        
        $(".modal").on("hidden.bs.modal", function () {
    
            $(".messages-list").html("");
            // $("#input-me").attr("autocomplete", "off");
        });
        $(".close").click(function () {
    
            globalVariable = "";
            globalqueryarray = []
            $(".chat_box").css("right", "-360px");
            $('#input-me').val('')
            $(".messages-list").html("");
            localStorage.clear();
            retobj = {};
         })
        setInterval(function () {
            $(".chat_icon").css("animation", "shake-chat-icon");
        }, 500);
    
   

    if(popupOpen ==true){
            var title = "EVA Healthcare Assistant";
    
            $("#MyPopup .modal-title").html(title);
            $("#MyPopup").modal("show");
            $(".chat_box").css("right", "10px");
    
            (function ($) {
                $.ajax({
                    url: 'http://localhost:3000/api/session',
                    // url: 'https://eva-healthcare-bot.mybluemix.net/api/session',
                    type: 'Get',
                    success: function (result) {
                        sessionStorage.setItem('Sessionid', result.data.session_id)
                        send_msg('1')
                    }
                })
            })($)
        
        $(".modal").on("hidden.bs.modal", function () {
            $(".messages-list").html("");
            // $("#input-me").attr("autocomplete", "off");
        });
        $(".close").click(function () {
            popupOpen = false
            globalVariable = "";
            globalqueryarray = []
            $(".chat_box").css("right", "-360px");
            $('#input-me').val('')
            $(".messages-list").html("");
            localStorage.clear();
            retobj = {};
         })
        setInterval(function () {
            $(".chat_icon").css("animation", "shake-chat-icon");
        }, 500);
    }


});
$('#input-me').keypress(function (e) {
    if (e.which == 13) {
        $('#click-me').click();
    }
});
function sendMessageToWatson(options, type, text) {
    var htm2 = '<div id="ok" style="margin-left:-14px" class="typing-indicator"><li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/eva.png"></span>EVA is typing...<span></span<span></span></p></li></div>'
    $('.messages-list').append(htm2)
    $.ajax({
        // url: 'http://localhost:3000/api/message',
        url: 'https://eva-healthcare-bot.mybluemix.net/api/message',
        type: 'Post',
        data: { session_id: sessionStorage.getItem('Sessionid'), message: text, data: options, type: type },
        success: function (result) {
            var delay = 2000;
            setTimeout(function () {
                if (result) {
                    result.forEach((element, index) => {
                        $('#ok').remove();
                        if (element.response_type == "text") {
                            var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/eva.png"></span><span class="messages-bot" style="font-weight: 500">' + element.text + '</span><div class="message-header"></div></p></li>'
                            $('.messages-list').append(html)
                        }
                        if (element.response_type == "option") {
                            if (element.description) {
                                if (element.description == 'thanksInputsTaken') {
                                    var localstorageArray = JSON.parse(localStorage.getItem('patient'))
                                    const patientData = Object.assign({}, ...localstorageArray);
                                    $.ajax({
                                        // url: 'http://localhost:3000/api/sendMail',
                                        url: 'https://eva-healthcare-bot.mybluemix.net/api/sendMail',
                                        type: 'Post',
                                        data: patientData,
                                        success: function (result) {
                                              console.log(" result of inputthanks", result)
                                              if(result && result.code == 200){
                                                localStorage.clear();

                                              }
                                        }
                                    })
                                }
                                if (element.description == 'parentService' || element.description == 'thanks') {
                                    localStorage.clear();
                                }
                                var obj = {
                                    'description': result[index].description
                                }
                                for (var key in obj) {
                                    retobj[obj[key]] = null;
                                }
                            }
                            var html = '<li class="msg-bot clearfix"><p><span class="messages-bot-icon"><img src="images/eva.png"></span><span class="messages-bot" style="font-weight: 500">' + element.title + '</p></li>'
                            $('.messages-list').append(html)
                            element.options.forEach((innerele) => {
                                if(innerele.label == 'Go to main menu' || innerele.label == 'Go to sub menu'){
                                    var html1 = '<li  class="msg-bot clearfix"><div class="col-sm-6 message-header"><input type="button"  id="no' + i + '" style="margin-left: 4px; margin-top: 3px; font-weight: 500" class="btn btn-info block" value="' + innerele.label + '" onclick="callOptions(' + i + ')">' + '</div></li>'
                                    $('.messages-list').append(html1)
                                    
                                }
                                else {
                                    var html1 = '<li  class="msg-bot clearfix"><div class="col-sm-6 message-header"><input type="button"  id="no' + i + '" style="margin-left: 4px; margin-top: 3px; font-weight: 500" class="btn btn-primary block" value="' + innerele.label + '" onclick="callOptions(' + i + ')">' + '</div></li>'
                                    $('.messages-list').append(html1)
                                } 
                           
                                i++

                            })
                        }
                        $('.list-unstyled').animate({
                            scrollTop: $('.list-unstyled')[0].scrollHeight
                        }, "fast");
                    });
                }

                else {
                    console.log('Error occured')
                }
            }, delay);
        }
    })
}

function send_msg(defaultInput) {
    var text = $('#input-me').val()
    if (/^\s*$/.test(text) && defaultInput == '2') {
        return;
    }
    if (text == '') {
        sendMessageToWatson('', '', '')
    }
    else {
        $('.list-unstyled').animate({
            scrollTop: $('.list-unstyled')[0].scrollHeight
        }, "fast");
        if (text) {
            var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"></span><span class="messages-user" style="font-weight: 550">' + text + '</span><div class= "message-header"></div></p></li>'
            // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'
            $('.messages-list').append(html)
            $('#input-me').val('')
            if (globalVariable == 'query') {
                raiseQuery(text)
            }
            else {
                Object.keys(retobj)[0] = text
                retobj[Object.keys(retobj)[0]] = text
                let patientArray = [];
                if (localStorage.getItem('patient') && localStorage.getItem('patient').length) {
                    var localstorageArray = JSON.parse(localStorage.getItem('patient'))
                    var ind;
                    localstorageArray.forEach(function (item, index) {
                        if (item.hasOwnProperty(Object.keys(retobj)[0])) {
                            ind = index
                        }
                    })
                    if (ind != undefined) {
                        localstorageArray.splice(ind, 1);
                    }

                    if (Object.keys(retobj)[0] != "undefined") {
                        localstorageArray.push(retobj)
                    }
                    localStorage.setItem('patient', JSON.stringify(localstorageArray));

                }
                if (!localStorage.getItem('patient')) {
                    patientArray.push(retobj);
                    localStorage.setItem('patient', JSON.stringify(patientArray));
                }
                sendMessageToWatson('', '', text)
                retobj = {}

            }
        }
    }

}
function refresh(){
    $(".messages-list").html("");
    (function ($) {
        $.ajax({
            // url: 'http://localhost:3000/api/session',
            url: 'https://eva-healthcare-bot.mybluemix.net/api/session',
            type: 'Get',
            success: function (result) {
                sessionStorage.setItem('Sessionid', result.data.session_id)
                send_msg('1')
                retobj = {}

            }
        })
    })($)

}
function callOptions(i) {
    $(".block").attr("disabled", true)
    var value = $('#no' + i).val()
    if(value == "Go to main menu" || value == "Go to sub menu"){
         if(value == "Go to sub menu"){
            var localstorageArray = JSON.parse(localStorage.getItem('patient'))
                if(localstorageArray && localStorage.length){
                    localstorageArray.pop();
                    localStorage.setItem('patient', JSON.stringify(localstorageArray));
                }
               
         }
        $('.list-unstyled').animate({
            scrollTop: $('.list-unstyled')[0].scrollHeight
        }, "fast");
        var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"></span><span class="messages-user" style="font-weight: 550">' + value + '</span><div class= "message-header"></div></p></li>'
        // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'
        $('.messages-list').append(html)
        $('#input-me').val('')
        sendMessageToWatson('', '', value)
        retobj = {}
        return;
    }
    Object.keys(retobj)[0] = value
    retobj[Object.keys(retobj)[0]] = value
    let patientArray = [];
    // if(localStorage.getItem('patient') && localStorage.getItem('patient').length){
    //     console.log('logssssss')
    //     var localstorageArray =JSON.parse(localStorage.getItem('patient'))
    //     localstorageArray.push(retobj)
    //     localStorage.setItem('patient', JSON.stringify(localstorageArray));

    //  }
    if (localStorage.getItem('patient') && localStorage.getItem('patient').length) {
        var localstorageArray = JSON.parse(localStorage.getItem('patient'))
        var ind;
        localstorageArray.forEach(function (item, index) {
            if (item.hasOwnProperty(Object.keys(retobj)[0])) {
                ind = index
            }
        })
        
        if (ind != undefined) {
            localstorageArray.splice(ind, 1);
        }
        if (Object.keys(retobj)[0] != "undefined") {
            localstorageArray.push(retobj)
        }
        localStorage.setItem('patient', JSON.stringify(localstorageArray));

    }

    if (!localStorage.getItem('patient')) {
        patientArray.push(retobj);
        localStorage.setItem('patient', JSON.stringify(patientArray));
    }
       console.log('valueeeeeeeeeee', value)
    if (value == 'COVID_19 Vaccination FAQs for 18-44 Year Age Group') {
        window.open('https://healthyhcl.in/assets/mailer/English%20FAQ%20on%2018+%20Vaccination_210507_132400.pdf', '_blank');
    }
    if (value == 'Vaccination service at HCL') {
        window.open('https://healthyhcl.in/assets/mailer/COVID%20Vaccination%20-%20Information%20Flyer_HCLH.pdf', '_blank');
    }
    if (value == 'DOs & DONTs before & after Vaccination') {
        window.open('https://healthyhcl.in/assets/mailer/COVID-%20Dos%20&%20Donts%20Poster%20-%202%20x%203%20ft-V5.pdf', '_blank');
    }
    if (value == 'RTPCR testing details') {
        window.open('https://healthyhcl.in/assets/mailer/KIOSK.pdf', '_blank');
    }
    if (value == 'Book a new health check appointment') {
        window.open('https://healthyhcl.in/ehc/register.php', '_blank');
    }
    if (value == 'Feedback & Grievances' || value == 'Feedback &  Grievances') {
        window.open('https://forms.office.com/Pages/ResponsePage.aspx?id=N-edGDrJWk-LaG9MqZQZEodG5hcOIUhGgmopShXPBE5UME1SWjhDWDhUR0g4R1E0T0pSME8xOFVFWSQlQCN0PWcu', '_blank');
    }
    if (value == 'Vaccination Services') {
        window.open('https://healthyhcl.in/covidmanagement.html#animationblink', '_blank');
    }

    $('.list-unstyled').animate({
        scrollTop: $('.list-unstyled')[0].scrollHeight
    }, "fast");
    var html = '<li class="msg-user clearfix"><p><span class="messages-user-icon"></span><span class="messages-user" style="font-weight: 550">' + value + '</span><div class= "message-header"></div></p></li>'
    // var html = '<li class="messages-me clearfix"><div class= "message-header"><strong class="messages-title">Me</strong><small class="text-messages text-muted"></small></div><p class="messages-p">'+text+'</p>'
    $('.messages-list').append(html)
    $('#input-me').val('')
    sendMessageToWatson('', '', value)
    retobj = {}

}

