var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var UserSchema = new Schema({
    empId : {
        type: String,
        default: null

    },
    parentService: {
       type: String,
       default: null

   },
   covidorNoncovid_service: {
        type: String,
        default: null

    },
    inputMessage: {
        type: String,
        default: null

    },
    freeorDiscountedService: {
        type: String,
        default: null

    },
    freeDentalorLifeCoach: {
        type: String,
        default: null

    },
    discountedPriceService: {
        type: String,
        default: null

    },
    gynoYesorNo: {
        type: String,
        default: null
    },
    dentalYesorNo: {
        type: String,
        default: null

    },
    employeEntity:{
        type: String,
        default: null

    },
    whoInitiatingChat:{
        type: String,
        default: null

    },
    whomSeekingAssistance:{
        type: String,
        default: null

    },
    beneficiaryName:{
        type: String,
        default: null

    },
    beneficiaryNumber:{
        type: String,
        default: null

    },
    patientGender:{
        type: String,
        default: null

    },
    patientState:{
        type: String,
        default: null

    },
    patientCity:{
        type: String,
        default: null
    },
    dob:{
        type: String,
        default: null
    },
    feverishYesorNo : {
        type: String,
        default: null
    },
    spo2level : {
        type: String,
        default: null
    },
    internalMedicineYesorNo : {
        type: String,
        default: null
    },
    pediaYesorNo : {
        type: String,
        default: null
    },
    orthoYesorNo:  {
        type: String,
        default: null
    },
    dieticianYesorNo: {
        type: String,
        default: null
    },
    selectedDovidService: {
        type: String,
        default: null
    },
    essentialOrDocConsult: {
        type: String,
        default: null
    },
    dentalProcedures: {
        type: String,
        default: null
    },
    healthCheck :{
        type: String,
        default: null
    },
    carePlan:{
        type: String,
        default: null
    }

}, { timestamps: { createdAt: 'created_at', updatedAt: 'updated_at' } });

var users = mongoose.model('users', UserSchema);
module.exports = users;