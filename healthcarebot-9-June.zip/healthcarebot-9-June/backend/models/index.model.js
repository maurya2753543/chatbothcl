const Users = require("./user.model")
module.exports = {
    Users: Users
};
