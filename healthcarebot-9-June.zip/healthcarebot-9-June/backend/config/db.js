/**
Description : The file will take care of the database connectivity 
*/
var bluebird = require('bluebird');

var mongoose = require('mongoose');

mongoose.Promise = bluebird;


// Connecting to local system Database
//  mongoose.connect("mongodb+srv://akshaypant:LZLQCFNT3wgXcjG4@cluster0.usjle.mongodb.net/demobot?retryWrites=true&w=majority",{ useNewUrlParser: true,  useUnifiedTopology: true }  );
//  mongodb://akshaypant:LZLQCFNT3wgXcjG4@cluster0-shard-00-00.usjle.mongodb.net:27017,cluster0-shard-00-01.usjle.mongodb.net:27017,cluster0-shard-00-02.usjle.mongodb.net:27017/myFirstDatabase?ssl=true&replicaSet=atlas-137n3c-shard-0&authSource=admin&retryWrites=true&w=majority
// mongoose.connect("mongodb://127.0.0.1:27017",{ useNewUrlParser: true,  useUnifiedTopology: true }  );


/**Personal DB atlas instance */
// mongoose.connect("mongodb+srv://healthcare:Password@ap01@newcluster.tzeea.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",{ useNewUrlParser: true,  useUnifiedTopology: true });



/**IBM cloud DB */
mongoose.connect("mongodb://admin:LPRMOJNBDCTIQRZM@portal-ssl788-55.bmix-dal-yp-394615a1-4cf1-499c-8e6a-66b8ae77aa5f.925132281.composedb.com:24317,portal-ssl1326-48.bmix-dal-yp-394615a1-4cf1-499c-8e6a-66b8ae77aa5f.925132281.composedb.com:24317/evaHealthcare?authSource=admin&ssl=true",{ useNewUrlParser: true,  useUnifiedTopology: true, retryWrites: false })
// Creating mongoose connection instance
var db = mongoose.connection;

// CONNECTION EVENTS
// When successfully scheduleconnected
db.on('connected', function () {
  console.log('Mongoose default connection open');
});

// When the connection is disconnected
db.on('disconnected', function () {
  console.log('Mongoose default connection disconnected');
});

// If the connection throws an error
db.on('error', function (err) {
  console.log('Mongoose default connection error: ' + err);
});

// If the Node process ends, close the Mongoose connection 
process.on('SIGINT', function () {
  mongoose.connection.close(function () {
    console.log('Mongoose default connection disconnected through app termination');
    process.exit(0);
  });
});
