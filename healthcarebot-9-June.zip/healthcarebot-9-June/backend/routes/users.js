var express = require('express');
var router = express.Router();
const models = require('../models/index.model');
var botController = require('../controller/bot')
/* GET users listing. */

router.post('/message',botController.SendMessage)
router.get('/session',botController.createSession)
router.post('/sendMail',botController.sendMail)

module.exports = router;
