require('dotenv').config()

const fetch = require('node-fetch');

const O365_TENANT_ID = process.env.O365_TENANT_ID
const O365_CLIENT_ID = process.env.O365_CLIENT_ID
const O365_CLIENT_SECRET = process.env.O365_CLIENT_SECRET
const O365_SENDER_ID = process.env.O365_SENDER_ID
const O365_RECIPIENT_EMAILS = process.env.O365_RECIPIENT_EMAILS

async function sendMessage(to, subject, text, attachment) {
    to = O365_RECIPIENT_EMAILS
    to = to.replace(/\s+/g, '');
    let emails = to.split(";")
    
    let item, addresses = []
    for (e in emails) {
        item = {}
        item.emailAddress = {address: emails[e]}
        addresses.push(item)
    }

    let res = await fetch(`https://login.microsoftonline.com/${O365_TENANT_ID}/oauth2/v2.0/token`, {
        method: 'post',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `client_id=${O365_CLIENT_ID}&scope=https%3A%2F%2Fgraph.microsoft.com%2F.default&client_secret=${O365_CLIENT_SECRET}&grant_type=client_credentials`
    })
    let token = await res.json()

    console.log(`Sending message to ${addresses} at ${new Date().toLocaleTimeString()}`)
    console.log(text)
    console.log()

    let message = {
        message: {
            subject: subject,
            body: {
                contentType: 'Text',
                content: text
            },
            toRecipients: addresses
        },
        saveToSentItems: 'true'
    }

    // Send with attachment
    let sendMail = await fetch(`https://graph.microsoft.com/v1.0/users/${O365_SENDER_ID}/sendMail`, {
        method: 'post',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `${token.token_type} ${token.access_token}`
        },
        body: JSON.stringify(message),
        attachments: [
            {
                '@odata.type': '#microsoft.graph.fileAttachment',
                name: 'attachment.json',
                contentType: 'binary',
                contentBytes: attachment
            }
        ]
    })
    .then(res => {
        console.log(res.headers)
    })
    .catch(error => console.log(error))

    await sendMail

}
   























async function SendMessage(req, res) {
    // try {
      console.log('send message fun updated')
      // console.log('message>>>>>>>>>',req.body,'messahe')
  
      // async function sendMessage(to, subject, text, attachment) {
      
        to = "akshay.pant@hcl.com"
        to = to.replace(/\s+/g, '');
        let emails = to.split(";")
        
        let item, addresses = []
        for (e in emails) {
            item = {}
            item.emailAddress = {address: emails[e]}
            addresses.push(item)
        }
    try{
      let res =  await fetch(`https://login.microsoftonline.com/189de737-c93a-4f5a-8b68-6f4ca9941912/oauth2/v2.0/token`, {
        method: 'post',
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: `client_id=da8f0ea1-5a6f-4cd5-b531-0bc213b9ce60&scope=https%3A%2F%2Fgraph.microsoft.com%2F.default&client_secret=Hd.6mCwrE6-I.z95a4~4ilUADW6_kWzUGh&grant_type=client_credentials`
    })
    var token = await res.json()
    console.log(`Sending message to ${addresses} at ${new Date().toLocaleTimeString()}`)
    // console.log(text)
    console.log('token>>>>>>>', token)
    
    let message = {
      message: {
          subject: "Eva",
          body: {
              contentType: 'Text',
              content: "text"
          },
          toRecipients: addresses
      },
      saveToSentItems: 'true'
  }
     try{
       console.log('token<<<<<<<<<<', token)
      let sendMail = await  fetch(`https://graph.microsoft.com/v1.0/users/customerexperience@hcl.com/sendMail`, {
        method: 'post',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `${token.token_type} ${token.access_token}`
        },
        body: JSON.stringify(message),
        // attachments: [
        //     {
        //         '@odata.type': '#microsoft.graph.fileAttachment',
        //         name: 'attachment.json',
        //         contentType: 'binary',
        //         contentBytes: attachment
        //     }
        // ]
    })
         let headers= await sendMail.json()
         console.log('headers>>>>.', headers)
     }
  catch(err){
    console.log('errrr errrrrrrrr', err)
  
  }
    } catch(e){
      console.log('errrr eeeeeeee', e)
    }
       
    
       
    
    
        // // Send with attachment
        // let sendMail = await  fetch(`https://graph.microsoft.com/v1.0/users/customerexperience@hcl.com/sendMail`, {
        //     method: 'post',
        //     headers: {
        //         'Content-Type': 'application/json',
        //         'Authorization': `${token.token_type} ${token.access_token}`
        //     },
        //     body: JSON.stringify(message),
        //     // attachments: [
        //     //     {
        //     //         '@odata.type': '#microsoft.graph.fileAttachment',
        //     //         name: 'attachment.json',
        //     //         contentType: 'binary',
        //     //         contentBytes: attachment
        //     //     }
        //     // ]
        // })
        // .then(res => {
        //     console.log('response herader',res.headers)
        // })
        // .catch(error =>{
        //   console.log('erorrrr in catch',error)
        // } )
         
    
    
  
  
      //   var transporter = nodemailer.createTransport({
      //     host: 'HCL-COM.mail.protection.outlook.com',
      //     port: '25',
      //     // service: 'SMTP',
      //     // secure: false, // true for 465, false for other ports
      //     // type:"SMTP",   
      //     // requireTLS: true,
      //      auth: {
      //         user: 'support.healthcare@hcl.com',
      //         pass:  'Comnet@123' 
      //     },
      //   //   tls: {
      //   //     rejectUnauthorized: false,
      //   // }
  
  
      // });
      // var mailOptions = {
      //     from: 'customerexperience@hcl.com',
      //     to: 'pantakshay007@gmail.com',
      //     subject: 'EVA Healthcare Assistant',
      //     html: '<!DOCTYPE html>' +
      //     '<html lang="en">' +
      //     '<head>' +
      //     '<meta charset="utf-8">' +
      //     '<meta http-equiv="X-UA-Compatible" content="IE=edge">' +
      //     '<meta name="viewport" content="width=device-width, initial-scale=1">' +
      //     '<meta name="description" content="">' +
      //     '<meta name="author" content="">' +
      //     '<title>Healthcare bot</title>' +
      //     '</head>' +
      //     '<body>' +
      //     '<table style="width: 100%;font-family: SF Text;"">' +
      //     '<tr>' +
      //     '<td></td>' +
      //     '<td bgcolor="#FFFFFF ">' +
      //     '<div style="padding: 15px; max-width: 600px;margin: 0 auto;display: block; border-radius: 0px;padding: 0px;box-shadow: 0 5px 10px rgba(0,0,0,0.3);">' +
      //     '<table style="width: 100%;background: #142540 ;">' +
      //     '<tr>' +
      //     '<td></td>' +
      //     '<td>' +
      //     '<div>' +
      //     '<table width="100%">' +
      //     '<tr>' +
      //     '<td rowspan="2" style="text-align:center;padding:10px;">' +
      //     '</td>' +
      //     '</tr>' +
      //     '</table>' +
      //     '</div>' +
      //     '</td>' +
      //     '<td></td>' +
      //     '</tr>' +
      //     '</table>' +
      //     '<table style="padding:10px;font-size:14px; width:100%;">' +
      //     '<tr>' +
      //     '<td style="padding:10px;font-size:14px; width:100%;">' +
      //     '<p><strong> Hi,' + ' ' + 'Akshay' + " " + 'Pant' + ',' + '</strong></p>' +
      //     ' <p><br /> Welcome to Healthcare bot.Please use the below credentials for login to the admin portal. <p><br />' +
      //     'email - <span><strong> ' + 'email' + '</strong></span> <br/>' +
      //     'Password - <span><strong> ' + 'password' + '</strong></span>' +
      //     '</td>' +
      //     '</tr>' +
      //     '<tr>' +
      //     '<td>' +
      //     // '<div align="center" style="font-size:15px;margin: 10px 0px; padding:5px; width:100%;"><a style="margin: 0 0 3px" href="https://play.google.com/store/apps/details?id=com.app.adtrack"><img src="https://www.adtrak.com.au/assets/img/paly.png" width="130"></a>' +
      //     '</div>' +
      //     '</td' +
      //     '</tr>' +
      //     '</table>' +
      //     '<table style="width: 100%;background: #b3b3c3; color: #fff;">' +
      //     '<tr>' +
      //     '<td>' +
      //     '<div align="center" style="font-size:12px;margin: 10px 0px; padding:5px; width:100%;">© 2018 <a href="#" style="text-decoration:none;color:#fff;"> Healthcare. All rights reserved.</a>' +
      //     '</div>' +
      //     '</td>' +
      //     '</tr>' +
      //     '</table>' +
      //     '</div>' +
      //     '</td>' +
      //     '</tr>' +
      //     '</table>' +
      //     '</body>' +
      //     '</html>'
      // };
      // transporter.sendMail(mailOptions, function (err) {
      //     if (err) {
      //         console.log("err while sending mailssssssssssssssss", err)
      //         // return res.json(Response(500, "failed", utility.validationErrorHandler(err), err));
      //     } else {
      //           console.log('mail sentr>>>>>>')
      //         // return res.json(Response(200, "success", constantsObj.messages.subadminAddSuccess, { _id: userData._id }));
      //     }
      // });
      let assistantId = process.env.ASSISTANT_ID || '<assistant-id>';
      if (!assistantId || assistantId === '<assistant-id>') {
        return res.json({
          output: {
            text: "Error"
  
          }
        });
      }
  
      var textIn = '';
      if (req.body.message) {
        textIn = req.body.message;
      }
      var payload = {
        assistantId: assistantId,
        sessionId: req.body.session_id,
        input: {
          message_type: 'text',
          text: textIn,
        },
      };
  
  
      let data = await WatsonMessageHelper(payload)
      // console.log(payload,'req.body.type')
  
      if (req.body.type == 'query') {
        let splitted_data = data.result.output.generic[0].text.split('/n')
        // console.log(splitted_data,'lop')
        combined_data = []
        combined_data.push({ response_type: "text", type: "", text: splitted_data[0] + '<strong>' + req.body.data + '</strong>' + splitted_data[1] })
        combined_data.push(data.result.output.generic[1])
        console.log(combined_data)
        // console.log(splitted_data,data.result.output.generic,'in the splitted value')
        return res.json(combined_data)
  
  
      }
  
  
      else {
        // console.log('data.result.output.generic[0]>>>>', data.result.output)
        data.result.output.generic[0].type = ""
  
        return res.json(data.result.output.generic)
      }
    // }
    // catch (e) {
    //   console.log(e, 'error+error')
    //   return res.json({ code: 404, message: "Message Error" })
  
    //   // return res.status(status).json(e);
  
  
    // }
  
  }